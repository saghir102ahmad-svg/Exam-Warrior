# Exam Warrior AI — Build Plan

A modern, AI-powered study platform for school, college, and university students. Built as a mobile-first web app with React (TanStack Start) + Lovable Cloud (replaces Firebase — gives you auth, database, storage, and AI with no external accounts).

## Phase 1 — Foundation (this build)

**Design & shell**
- Bold, student-focused design system: dark-mode-first with an energetic accent palette, smooth animations, clean dashboard layout
- Responsive app shell: sidebar on desktop, bottom navigation on mobile
- Landing page with feature showcase and pricing preview

**Authentication & profiles**
- Email/password + Google sign-in
- Student profile: name, avatar, education level (school/college/university), language preference (English/Urdu)

**Core AI features**
- **AI Notes Generator** — paste text or upload PDFs/images → short notes & chapter summaries (English + Urdu)
- **AI MCQ Generator** — generate MCQs from notes/chapters with Easy/Medium/Hard difficulty, instant checking + explanations
- **AI Flashcards** — auto-generate flashcards, flip-card UI, spaced repetition scheduling, favorites
- **DoubtSnap AI** — photo upload → OCR via AI vision → step-by-step solution (Math, Physics, Chemistry, Biology, CS, English)
- **AI Study Assistant** — 24/7 chatbot with streaming responses, explains concepts, generates examples

**Study management**
- Subject & chapter management
- Smart Revision Planner: enter exam date + subjects → AI-generated daily timetable with goals and progress tracking
- Exam countdown widget + daily motivation quote on dashboard

**Gamification (StudyQuest)**
- XP for every study action, levels, daily streaks
- Badges & achievements
- Global leaderboard

**Dashboard**
- Stats & charts: study time, quiz accuracy, streak, XP progress
- Weak Topic Analyzer: quiz performance breakdown by subject/chapter with targeted revision recommendations

## Phase 2 — Later iterations (not in this build)

- Study Battle Mode (real-time quiz battles, tournaments)
- 7-Day Exam Rescue Mode
- Pomodoro timer, attendance & homework trackers
- Admin panel (user/content management, analytics, broadcasts)
- Premium subscriptions & referral program (payments need a Pro plan — we'll set up Stripe/Paddle when ready)
- Push notifications & offline access

## Technical Details

- **Stack**: TanStack Start (React), Tailwind CSS, Lovable Cloud backend
- **Auth**: Lovable Cloud auth (email/password + Google)
- **Database**: Postgres with row-level security — tables for profiles, subjects, chapters, notes, quizzes, quiz_attempts, flashcards, flashcard_reviews, study_plans, plan_tasks, xp_events, achievements, user_achievements, streaks
- **AI**: Lovable AI Gateway (multimodal models for OCR/vision, text generation for notes/MCQs/flashcards, streaming chat)
- **Storage**: Cloud storage bucket for uploaded PDFs/images
- **Gamification**: XP awarded server-side on actions (quiz completed, notes generated, streak maintained) to prevent cheating

Phase 1 is already a large build — it will land as a fully working app you can test end to end, then we iterate on Phase 2 features one by one.