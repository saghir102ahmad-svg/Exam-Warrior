CREATE POLICY "Users read own book files" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'books' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users upload own book files" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'books' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users delete own book files" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'books' AND auth.uid()::text = (storage.foldername(name))[1]);