
DROP VIEW IF EXISTS public.leaderboard_profiles;

CREATE OR REPLACE FUNCTION public.get_leaderboard(_limit int DEFAULT 50)
RETURNS TABLE (
  user_id uuid,
  display_name text,
  xp int,
  level int,
  streak_count int
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.user_id, p.display_name, p.xp, p.level, p.streak_count
  FROM public.profiles p
  ORDER BY p.xp DESC
  LIMIT GREATEST(1, LEAST(_limit, 100));
$$;

REVOKE ALL ON FUNCTION public.get_leaderboard(int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_leaderboard(int) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_leaderboard(int) TO service_role;
