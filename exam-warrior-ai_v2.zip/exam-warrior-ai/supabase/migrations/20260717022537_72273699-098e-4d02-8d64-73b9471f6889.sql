-- ============ app_config (singleton) ============
CREATE TABLE public.app_config (
  id INTEGER PRIMARY KEY DEFAULT 1,
  current_version TEXT NOT NULL DEFAULT '1.0.0',
  min_required_version TEXT NOT NULL DEFAULT '1.0.0',
  update_url TEXT,
  update_message TEXT NOT NULL DEFAULT 'A new version is required. Please update to continue.',
  force_update BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID,
  CONSTRAINT app_config_singleton CHECK (id = 1)
);

GRANT SELECT ON public.app_config TO anon, authenticated;
GRANT ALL ON public.app_config TO service_role;
ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "app_config readable by everyone"
  ON public.app_config FOR SELECT
  USING (true);

CREATE POLICY "Admins can update app_config"
  ON public.app_config FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.app_config (id) VALUES (1) ON CONFLICT DO NOTHING;

-- ============ chat_messages ============
CREATE TABLE public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX chat_messages_user_created_idx ON public.chat_messages (user_id, created_at DESC);

GRANT SELECT, INSERT ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chats"
  ON public.chat_messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));

CREATE POLICY "Users can insert own chats"
  ON public.chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can delete chats"
  ON public.chat_messages FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));