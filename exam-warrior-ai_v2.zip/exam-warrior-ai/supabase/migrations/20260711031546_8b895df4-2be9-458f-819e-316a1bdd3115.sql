
-- 1. Trigger: block non-service-role writes to stat columns on profiles
CREATE OR REPLACE FUNCTION public.prevent_profile_stats_write()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    NEW.xp := OLD.xp;
    NEW.level := OLD.level;
    NEW.streak_count := OLD.streak_count;
    NEW.last_study_date := OLD.last_study_date;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_prevent_stats_write ON public.profiles;
CREATE TRIGGER profiles_prevent_stats_write
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.prevent_profile_stats_write();

-- 2. Tighten SELECT policy on profiles: only own row
DROP POLICY IF EXISTS "Signed-in users can view profiles (leaderboard)" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- 3. Leaderboard view exposing only safe columns.
--    security_invoker=false (default) => uses view owner's rights to read
--    the base table, so authenticated users can read leaderboard data
--    without needing broad SELECT on profiles itself.
DROP VIEW IF EXISTS public.leaderboard_profiles;
CREATE VIEW public.leaderboard_profiles
WITH (security_invoker = false)
AS
SELECT user_id, display_name, xp, level, streak_count
FROM public.profiles;

GRANT SELECT ON public.leaderboard_profiles TO authenticated;
GRANT SELECT ON public.leaderboard_profiles TO service_role;
