CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;

CREATE TABLE public.books (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  author TEXT,
  subject_id UUID,
  file_path TEXT NOT NULL,
  page_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'processing',
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.books TO authenticated;
GRANT ALL ON public.books TO service_role;
ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own books" ON public.books FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.book_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID NOT NULL REFERENCES public.books(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  pdf_page INTEGER NOT NULL,
  book_page INTEGER,
  chapter TEXT,
  section TEXT,
  heading TEXT,
  para_index INTEGER NOT NULL DEFAULT 0,
  line_start INTEGER,
  line_end INTEGER,
  content TEXT NOT NULL,
  embedding extensions.vector(768),
  tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.book_chunks TO authenticated;
GRANT ALL ON public.book_chunks TO service_role;
ALTER TABLE public.book_chunks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own book chunks" ON public.book_chunks FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX book_chunks_book_idx ON public.book_chunks(book_id, pdf_page);
CREATE INDEX book_chunks_tsv_idx ON public.book_chunks USING gin(tsv);
CREATE INDEX book_chunks_embedding_idx ON public.book_chunks USING hnsw (embedding extensions.vector_cosine_ops);

CREATE TABLE public.book_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID NOT NULL REFERENCES public.books(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  confidence TEXT NOT NULL DEFAULT 'medium',
  citations JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.book_questions TO authenticated;
GRANT ALL ON public.book_questions TO service_role;
ALTER TABLE public.book_questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own book questions" ON public.book_questions FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.match_book_chunks(
  _book_id UUID,
  _embedding TEXT,
  _query TEXT,
  _limit INTEGER DEFAULT 8
)
RETURNS TABLE(
  id UUID, pdf_page INTEGER, book_page INTEGER, chapter TEXT, section TEXT,
  heading TEXT, line_start INTEGER, line_end INTEGER, content TEXT, score REAL
)
LANGUAGE sql
STABLE
SET search_path = public, extensions
AS $$
  WITH q AS (SELECT websearch_to_tsquery('english', COALESCE(NULLIF(_query,''), 'x')) AS tsq,
                    CASE WHEN _embedding IS NULL OR _embedding = '' THEN NULL ELSE _embedding::extensions.vector(768) END AS emb)
  SELECT c.id, c.pdf_page, c.book_page, c.chapter, c.section, c.heading,
         c.line_start, c.line_end, c.content,
         (COALESCE(CASE WHEN q.emb IS NULL THEN NULL ELSE 1 - (c.embedding OPERATOR(extensions.<=>) q.emb) END, 0) * 0.7
          + LEAST(ts_rank(c.tsv, q.tsq), 1.0) * 0.3)::real AS score
  FROM public.book_chunks c, q
  WHERE c.book_id = _book_id
  ORDER BY score DESC
  LIMIT GREATEST(1, LEAST(_limit, 20));
$$;
GRANT EXECUTE ON FUNCTION public.match_book_chunks(UUID, TEXT, TEXT, INTEGER) TO authenticated, service_role;