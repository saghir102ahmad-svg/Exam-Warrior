import type { BookChunkInput, ParsedPage } from "@/lib/book-types";

/** Lazily load pdf.js in the browser only (it touches DOM APIs that don't exist during SSR). */
export async function loadPdfJs() {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  return pdfjs;
}

const CHAPTER_RE =
  /^(chapter|unit|lesson|part|باب|سبق)\s*[-–:]?\s*([0-9]+|[IVXLCDM]+)\b\.?\s*(.*)$/i;
const SECTION_RE = /^(\d+(?:\.\d+){1,3})\s+(\S.*)$/;
const PAGE_LABEL_RE = /^(?:page\s*)?(\d{1,4})$/i;

/** Extract text lines per page, preserving page boundaries and reading order. */
export async function parsePdf(
  file: File,
  onProgress?: (page: number, total: number) => void,
): Promise<{ pages: ParsedPage[]; pageCount: number }> {
  const pdfjs = await loadPdfJs();
  const buffer = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data: buffer }).promise;
  const pages: ParsedPage[] = [];

  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const content = await page.getTextContent();

    // Group text items into visual lines by their y coordinate.
    const buckets = new Map<number, { x: number; str: string }[]>();
    for (const item of content.items as Array<{ str?: string; transform?: number[] }>) {
      const str = (item.str ?? "").replace(/\s+/g, " ");
      if (!str.trim() || !item.transform) continue;
      const y = Math.round(item.transform[5] / 3) * 3;
      const arr = buckets.get(y) ?? [];
      arr.push({ x: item.transform[4], str });
      buckets.set(y, arr);
    }

    const lines = [...buckets.entries()]
      .sort((a, b) => b[0] - a[0])
      .map(([, parts]) =>
        parts
          .sort((a, b) => a.x - b.x)
          .map((t) => t.str)
          .join(" ")
          .replace(/\s+/g, " ")
          .trim(),
      )
      .filter(Boolean);

    pages.push({ pdfPage: p, bookPage: detectBookPage(lines), lines });
    onProgress?.(p, doc.numPages);
    page.cleanup();
  }

  await doc.cleanup();
  return { pages, pageCount: doc.numPages };
}

/** Printed page numbers usually sit alone in the header or footer line. */
function detectBookPage(lines: string[]): number | null {
  const candidates = [lines[lines.length - 1], lines[0]];
  for (const line of candidates) {
    if (!line) continue;
    const m = line.trim().match(PAGE_LABEL_RE);
    if (m) {
      const n = Number(m[1]);
      if (n > 0 && n < 5000) return n;
    }
  }
  return null;
}

function looksLikeHeading(line: string): boolean {
  if (line.length > 80 || line.length < 3) return false;
  if (/[.!?،]$/.test(line)) return false;
  const words = line.split(" ");
  if (words.length > 12) return false;
  return CHAPTER_RE.test(line) || SECTION_RE.test(line) || /^[A-Z0-9][^a-z]*$/.test(line) || words.length <= 8;
}

/**
 * Build retrievable chunks that keep their exact location: page, printed page,
 * chapter, section/heading and the line range they were taken from.
 */
export function buildChunks(pages: ParsedPage[], maxChars = 900): BookChunkInput[] {
  const chunks: BookChunkInput[] = [];
  let chapter: string | null = null;
  let section: string | null = null;

  for (const page of pages) {
    let heading: string | null = null;
    let buf: string[] = [];
    let start = 0;
    let paraIndex = 0;

    const flush = (end: number) => {
      const content = buf.join(" ").replace(/\s+/g, " ").trim();
      buf = [];
      if (content.length < 40) return;
      chunks.push({
        pdfPage: page.pdfPage,
        bookPage: page.bookPage,
        chapter,
        section,
        heading,
        paraIndex: paraIndex++,
        lineStart: start,
        lineEnd: end,
        content,
      });
    };

    page.lines.forEach((line, i) => {
      const lineNo = i + 1;
      const chapterMatch = line.match(CHAPTER_RE);
      const sectionMatch = line.match(SECTION_RE);

      if (chapterMatch && looksLikeHeading(line)) {
        if (buf.length) flush(lineNo - 1);
        chapter = line.trim();
        section = null;
        heading = line.trim();
        return;
      }
      if (sectionMatch && looksLikeHeading(line)) {
        if (buf.length) flush(lineNo - 1);
        section = line.trim();
        heading = line.trim();
        return;
      }
      if (!buf.length && looksLikeHeading(line) && line.length < 60) {
        heading = line.trim();
      }

      if (!buf.length) start = lineNo;
      buf.push(line);

      const size = buf.join(" ").length;
      if (size >= maxChars) flush(lineNo);
    });

    if (buf.length) flush(page.lines.length);
  }

  return chunks;
}
