import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(context: { supabase: any; userId: string }, requireMod = false) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error("Role check failed");
  if (data) return "admin";
  if (requireMod) {
    const { data: modData } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "moderator",
    });
    if (modData) return "moderator";
  }
  throw new Error("Forbidden");
}

async function logAdmin(admin: any, adminUserId: string, action: string, targetType?: string, targetId?: string, details?: any) {
  await admin.from("admin_activity_logs").insert({
    admin_user_id: adminUserId,
    action,
    target_type: targetType,
    target_id: targetId,
    details: details ?? null,
  });
}

export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const now = new Date();
    const day = new Date(now.getTime() - 86400000).toISOString();
    const week = new Date(now.getTime() - 7 * 86400000).toISOString();
    const month = new Date(now.getTime() - 30 * 86400000).toISOString();

    const [{ count: totalUsers }, { count: last24h }, { count: last7d }, { count: last30d }, { count: banned }, notesRes, quizzesRes, doubtsRes, xpRes] = await Promise.all([
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }).gte("created_at", day),
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }).gte("created_at", week),
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }).gte("created_at", month),
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }).eq("is_banned", true),
      supabaseAdmin.from("notes").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("quizzes").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("doubts").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("xp_events").select("created_at, amount").gte("created_at", week).limit(5000),
    ]);

    // Active users in the last 7 days = distinct user_id from xp_events
    const { data: activeUsersData } = await supabaseAdmin
      .from("xp_events")
      .select("user_id")
      .gte("created_at", week)
      .limit(10000);
    const activeUsers = new Set((activeUsersData ?? []).map((r: any) => r.user_id)).size;

    // Daily signup buckets for last 14 days
    const { data: signupData } = await supabaseAdmin
      .from("profiles")
      .select("created_at")
      .gte("created_at", new Date(now.getTime() - 14 * 86400000).toISOString())
      .limit(5000);
    const buckets: Record<string, number> = {};
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 86400000);
      buckets[d.toISOString().slice(0, 10)] = 0;
    }
    (signupData ?? []).forEach((r: any) => {
      const key = new Date(r.created_at).toISOString().slice(0, 10);
      if (key in buckets) buckets[key]++;
    });

    return {
      totalUsers: totalUsers ?? 0,
      activeUsers,
      banned: banned ?? 0,
      last24h: last24h ?? 0,
      last7d: last7d ?? 0,
      last30d: last30d ?? 0,
      notes: notesRes.count ?? 0,
      quizzes: quizzesRes.count ?? 0,
      doubts: doubtsRes.count ?? 0,
      xpAwardedThisWeek: (xpRes.data ?? []).reduce((a: number, r: any) => a + (r.amount ?? 0), 0),
      signupBuckets: Object.entries(buckets).map(([date, count]) => ({ date, count })),
    };
  });

export const listAdminUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { search?: string; limit?: number; offset?: number }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const limit = Math.min(data.limit ?? 50, 200);
    const offset = data.offset ?? 0;

    let q = supabaseAdmin
      .from("profiles")
      .select("user_id, display_name, education_level, language, xp, level, streak_count, is_banned, created_at", { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);
    if (data.search) q = q.ilike("display_name", `%${data.search}%`);
    const { data: profiles, count } = await q;

    const userIds = (profiles ?? []).map((p: any) => p.user_id);
    const [{ data: roles }, { data: authList }] = await Promise.all([
      supabaseAdmin.from("user_roles").select("user_id, role").in("user_id", userIds.length ? userIds : ["00000000-0000-0000-0000-000000000000"]),
      supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 }),
    ]);
    const emailMap = new Map<string, string>();
    (authList?.users ?? []).forEach((u: any) => emailMap.set(u.id, u.email ?? ""));
    const rolesMap = new Map<string, string[]>();
    (roles ?? []).forEach((r: any) => {
      if (!rolesMap.has(r.user_id)) rolesMap.set(r.user_id, []);
      rolesMap.get(r.user_id)!.push(r.role);
    });

    return {
      total: count ?? 0,
      users: (profiles ?? []).map((p: any) => ({
        ...p,
        email: emailMap.get(p.user_id) ?? "",
        roles: rolesMap.get(p.user_id) ?? [],
      })),
    };
  });

export const setUserBan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; banned: boolean }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("profiles").update({ is_banned: data.banned }).eq("user_id", data.userId);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, data.banned ? "ban_user" : "unban_user", "user", data.userId);
    return { ok: true };
  });

export const deleteUserFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (data.userId === context.userId) throw new Error("Cannot delete yourself");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "delete_user", "user", data.userId);
    return { ok: true };
  });

export const setUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; role: "admin" | "moderator"; enabled: boolean }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.enabled) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.userId, role: data.role, granted_by: context.userId }, { onConflict: "user_id,role" });
      if (error) throw error;
    } else {
      if (data.role === "admin" && data.userId === context.userId) throw new Error("Cannot remove your own admin role");
      const { error } = await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId).eq("role", data.role);
      if (error) throw error;
    }
    await logAdmin(supabaseAdmin, context.userId, data.enabled ? "grant_role" : "revoke_role", "user", data.userId, { role: data.role });
    return { ok: true };
  });

export const listAdminContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { table: "notes" | "quizzes" | "doubts"; limit?: number }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const limit = Math.min(data.limit ?? 100, 500);
    const cols =
      data.table === "notes"
        ? "id, user_id, title, language, created_at"
        : data.table === "quizzes"
        ? "id, user_id, title, difficulty, created_at"
        : "id, user_id, question, created_at";
    const { data: rows, error } = await supabaseAdmin
      .from(data.table)
      .select(cols)
      .order("created_at", { ascending: false })
      .limit(limit);
    if (error) throw error;
    return { rows: rows ?? [] };
  });

export const deleteAdminContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { table: "notes" | "quizzes" | "doubts"; id: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from(data.table).delete().eq("id", data.id);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "delete_content", data.table, data.id);
    return { ok: true };
  });

export const sendBroadcast = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { title: string; message: string; target?: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    if (!data.title.trim() || !data.message.trim()) throw new Error("Title and message required");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("broadcast_notifications")
      .insert({
        title: data.title.slice(0, 200),
        message: data.message.slice(0, 2000),
        target: (data.target ?? "all").slice(0, 40),
        sent_by: context.userId,
      })
      .select()
      .single();
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "send_broadcast", "broadcast", row?.id, { title: data.title });
    return { ok: true, id: row?.id };
  });

export const listAdminLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { limit?: number }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows } = await supabaseAdmin
      .from("admin_activity_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(Math.min(data.limit ?? 200, 500));
    return { rows: rows ?? [] };
  });

export const listAdminTickets = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { status?: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin.from("support_tickets").select("*").order("created_at", { ascending: false }).limit(200);
    if (data.status) q = q.eq("status", data.status);
    const { data: rows } = await q;
    return { rows: rows ?? [] };
  });

export const updateAdminTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; status?: string; admin_reply?: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch: any = {};
    if (data.status) patch.status = data.status;
    if (data.admin_reply !== undefined) patch.admin_reply = data.admin_reply;
    const { error } = await supabaseAdmin.from("support_tickets").update(patch).eq("id", data.id);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "update_ticket", "ticket", data.id, patch);
    return { ok: true };
  });

export const upsertChangelog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id?: string; version: string; title: string; notes: string; released_at?: string; is_published?: boolean }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const payload: any = {
      version: data.version.slice(0, 40),
      title: data.title.slice(0, 200),
      notes: data.notes.slice(0, 5000),
      is_published: data.is_published ?? true,
    };
    if (data.released_at) payload.released_at = data.released_at;
    if (data.id) {
      const { error } = await supabaseAdmin.from("app_changelog").update(payload).eq("id", data.id);
      if (error) throw error;
    } else {
      const { error } = await supabaseAdmin.from("app_changelog").insert(payload);
      if (error) throw error;
    }
    await logAdmin(supabaseAdmin, context.userId, data.id ? "update_changelog" : "create_changelog", "changelog", data.id);
    return { ok: true };
  });

export const deleteChangelog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("app_changelog").delete().eq("id", data.id);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "delete_changelog", "changelog", data.id);
    return { ok: true };
  });

// ============= Kick user (revoke all sessions, don't delete) =============
export const kickUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    if (data.userId === context.userId) throw new Error("Cannot kick yourself");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Revoke all refresh tokens by briefly banning then unbanning
    const banRes = await supabaseAdmin.auth.admin.updateUserById(data.userId, { ban_duration: "1s" } as any);
    if (banRes.error) throw banRes.error;
    // Immediately clear the ban so the user can sign back in
    await supabaseAdmin.auth.admin.updateUserById(data.userId, { ban_duration: "none" } as any);
    await logAdmin(supabaseAdmin, context.userId, "kick_user", "user", data.userId);
    return { ok: true };
  });

// ============= App config (force update) =============
export const getAppConfig = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin.from("app_config").select("*").eq("id", 1).maybeSingle();
    return data;
  });

export const updateAppConfig = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { current_version?: string; min_required_version?: string; update_url?: string | null; update_message?: string; force_update?: boolean }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch: any = { updated_at: new Date().toISOString(), updated_by: context.userId };
    if (data.current_version !== undefined) patch.current_version = data.current_version.slice(0, 40);
    if (data.min_required_version !== undefined) patch.min_required_version = data.min_required_version.slice(0, 40);
    if (data.update_url !== undefined) patch.update_url = data.update_url ? data.update_url.slice(0, 500) : null;
    if (data.update_message !== undefined) patch.update_message = data.update_message.slice(0, 500);
    if (data.force_update !== undefined) patch.force_update = data.force_update;
    const { error } = await supabaseAdmin.from("app_config").update(patch).eq("id", 1);
    if (error) throw error;
    await logAdmin(supabaseAdmin, context.userId, "update_app_config", "app_config", "1", patch);
    return { ok: true };
  });

// ============= Chat viewer =============
export const listChatUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { search?: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Get distinct user_ids with recent chats
    const { data: rows } = await supabaseAdmin
      .from("chat_messages")
      .select("user_id, created_at")
      .order("created_at", { ascending: false })
      .limit(2000);
    const seen = new Map<string, string>();
    (rows ?? []).forEach((r: any) => { if (!seen.has(r.user_id)) seen.set(r.user_id, r.created_at); });
    const userIds = [...seen.keys()];
    if (!userIds.length) return { users: [] };
    let profQ = supabaseAdmin.from("profiles").select("user_id, display_name").in("user_id", userIds);
    if (data.search) profQ = profQ.ilike("display_name", `%${data.search}%`);
    const { data: profs } = await profQ;
    const filtered = (profs ?? []).map((p: any) => ({
      user_id: p.user_id,
      display_name: p.display_name,
      last_message_at: seen.get(p.user_id),
    })).sort((a, b) => (a.last_message_at! < b.last_message_at! ? 1 : -1));
    return { users: filtered };
  });

export const getUserChat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; limit?: number }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context, true);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows } = await supabaseAdmin
      .from("chat_messages")
      .select("id, role, content, created_at")
      .eq("user_id", data.userId)
      .order("created_at", { ascending: true })
      .limit(Math.min(data.limit ?? 500, 1000));
    const { data: prof } = await supabaseAdmin.from("profiles").select("display_name").eq("user_id", data.userId).maybeSingle();
    return { messages: rows ?? [], displayName: prof?.display_name ?? "Student" };
  });
