export type BookChunkInput = {
  pdfPage: number;
  bookPage: number | null;
  chapter: string | null;
  section: string | null;
  heading: string | null;
  paraIndex: number;
  lineStart: number | null;
  lineEnd: number | null;
  content: string;
};

export type ParsedPage = {
  pdfPage: number;
  bookPage: number | null;
  lines: string[];
};

export type Citation = {
  pdfPage: number;
  bookPage: number | null;
  chapter: string | null;
  section: string | null;
  heading: string | null;
  lineStart: number | null;
  lineEnd: number | null;
  quote: string | null;
};

export type BookAnswer = {
  answer: string;
  found: boolean;
  confidence: "high" | "medium" | "low";
  citations: Citation[];
};
