import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { callGateway, extractJson, type GatewayBlock } from "@/lib/ai-gateway.server";
import { awardXp } from "@/lib/xp";
import type { McqQuestion, FlashcardInput, PlanTaskInput } from "@/lib/study";
import type { Json } from "@/integrations/supabase/types";

// ---------- AI Notes Generator ----------

const NotesInput = z.object({
  title: z.string().min(1).max(200),
  sourceText: z.string().max(30000).optional(),
  imageDataUrl: z.string().optional(),
  language: z.enum(["english", "urdu"]),
  subjectId: z.string().uuid().nullable().optional(),
});

export const generateNotes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => NotesInput.parse(input))
  .handler(async ({ data, context }) => {
    if (!data.sourceText?.trim() && !data.imageDataUrl) {
      throw new Error("Please paste some text or upload an image of the chapter.");
    }

    const langInstruction =
      data.language === "urdu"
        ? "Write the notes entirely in Urdu (اردو), using clear Urdu script."
        : "Write the notes in clear, simple English.";

    const blocks: GatewayBlock[] = [
      {
        type: "text",
        text: `Create concise, exam-focused short notes and a chapter summary from this study material. Use markdown with headings, bullet points, **bold key terms**, and end with a "Quick Revision Summary" section of 5-8 one-line points. ${langInstruction}\n\nMaterial:\n${data.sourceText ?? "(see attached image of the chapter/page)"}`,
      },
    ];
    if (data.imageDataUrl) {
      blocks.push({ type: "image_url", image_url: { url: data.imageDataUrl } });
    }

    const content = await callGateway({
      system:
        "You are an expert teacher who creates short, high-yield revision notes for students. Be accurate, structured and concise.",
      content: blocks,
    });

    const { data: note, error } = await context.supabase
      .from("notes")
      .insert({
        user_id: context.userId,
        title: data.title,
        content,
        language: data.language,
        subject_id: data.subjectId ?? null,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);

    await awardXp(context.supabase, context.userId, "notes_generated");
    return note;
  });

// ---------- AI MCQ Generator ----------

const McqInput = z.object({
  title: z.string().min(1).max(200),
  sourceText: z.string().min(20).max(30000),
  difficulty: z.enum(["easy", "medium", "hard"]),
  count: z.number().int(),
  subjectId: z.string().uuid().nullable().optional(),
});

export const generateMcqs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => McqInput.parse(input))
  .handler(async ({ data, context }) => {
    const count = Math.min(15, Math.max(3, data.count));

    const raw = await callGateway({
      system:
        "You are an expert exam question writer. You output ONLY valid JSON, no prose, no code fences.",
      content: `Generate exactly ${count} multiple-choice questions at ${data.difficulty} difficulty from the material below. Return a JSON array where each item is {"question": string, "options": [4 strings], "answerIndex": number (0-3), "explanation": string (why the answer is correct, 1-2 sentences)}.\n\nMaterial:\n${data.sourceText}`,
    });

    let questions: McqQuestion[];
    try {
      questions = extractJson<McqQuestion[]>(raw).filter(
        (q) => q?.question && Array.isArray(q.options) && q.options.length >= 2,
      );
    } catch {
      throw new Error("The AI returned an unexpected format. Please try again.");
    }
    if (questions.length === 0) throw new Error("No questions could be generated. Try more material.");

    const { data: quiz, error } = await context.supabase
      .from("quizzes")
      .insert({
        user_id: context.userId,
        title: data.title,
        difficulty: data.difficulty,
        questions: questions as unknown as Json,
        subject_id: data.subjectId ?? null,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return quiz;
  });

// ---------- Quiz submission (server-side scoring + XP) ----------

const AttemptInput = z.object({
  quizId: z.string().uuid(),
  answers: z.array(z.number().int()),
});

export const submitQuizAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => AttemptInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: quiz, error } = await context.supabase
      .from("quizzes")
      .select("questions")
      .eq("id", data.quizId)
      .single();
    if (error || !quiz) throw new Error("Quiz not found");

    const questions = quiz.questions as unknown as McqQuestion[];
    let score = 0;
    questions.forEach((q, i) => {
      if (data.answers[i] === q.answerIndex) score++;
    });

    const { error: insertError } = await context.supabase.from("quiz_attempts").insert({
      user_id: context.userId,
      quiz_id: data.quizId,
      score,
      total: questions.length,
      answers: data.answers as unknown as Json,
    });
    if (insertError) throw new Error(insertError.message);

    await awardXp(context.supabase, context.userId, "quiz_completed");
    return { score, total: questions.length };
  });

// ---------- AI Flashcards ----------

const FlashcardsInput = z.object({
  title: z.string().min(1).max(200),
  sourceText: z.string().min(20).max(30000),
  count: z.number().int(),
  subjectId: z.string().uuid().nullable().optional(),
});

export const generateFlashcards = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => FlashcardsInput.parse(input))
  .handler(async ({ data, context }) => {
    const count = Math.min(25, Math.max(5, data.count));

    const raw = await callGateway({
      system: "You create study flashcards. You output ONLY valid JSON, no prose, no code fences.",
      content: `Create exactly ${count} flashcards from the material below. Return a JSON array of {"front": string (question/term), "back": string (concise answer/definition)}.\n\nMaterial:\n${data.sourceText}`,
    });

    let cards: FlashcardInput[];
    try {
      cards = extractJson<FlashcardInput[]>(raw).filter((c) => c?.front && c?.back);
    } catch {
      throw new Error("The AI returned an unexpected format. Please try again.");
    }
    if (cards.length === 0) throw new Error("No flashcards could be generated. Try more material.");

    const { data: deck, error } = await context.supabase
      .from("flashcard_decks")
      .insert({ user_id: context.userId, title: data.title, subject_id: data.subjectId ?? null })
      .select()
      .single();
    if (error || !deck) throw new Error(error?.message ?? "Could not create deck");

    const { error: cardsError } = await context.supabase.from("flashcards").insert(
      cards.map((c) => ({
        deck_id: deck.id,
        user_id: context.userId,
        front: c.front,
        back: c.back,
      })),
    );
    if (cardsError) throw new Error(cardsError.message);

    await awardXp(context.supabase, context.userId, "flashcards_generated");
    return deck;
  });

// ---------- DoubtSnap AI ----------

const DoubtInput = z.object({
  subject: z.string().min(1).max(50),
  questionText: z.string().max(5000).optional(),
  imageDataUrl: z.string().optional(),
});

export const solveDoubt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => DoubtInput.parse(input))
  .handler(async ({ data, context }) => {
    if (!data.questionText?.trim() && !data.imageDataUrl) {
      throw new Error("Please type a question or upload a photo of it.");
    }

    const blocks: GatewayBlock[] = [
      {
        type: "text",
        text: `Subject: ${data.subject}. ${
          data.imageDataUrl
            ? "First, extract the question text from the attached photo (OCR). Then solve it."
            : ""
        }Solve this question with a clear step-by-step solution in markdown. Start with "**Question:**" (the extracted/given question), then "**Solution:**" with numbered steps, then "**Answer:**" with the final answer, then a one-line "**Concept:**" explaining the key idea.\n\n${data.questionText ?? ""}`,
      },
    ];
    if (data.imageDataUrl) {
      blocks.push({ type: "image_url", image_url: { url: data.imageDataUrl } });
    }

    const solution = await callGateway({
      system:
        "You are a patient expert tutor for Mathematics, Physics, Chemistry, Biology, Computer Science and English. Show every step clearly and simply.",
      content: blocks,
    });

    const { data: doubt, error } = await context.supabase
      .from("doubts")
      .insert({
        user_id: context.userId,
        subject: data.subject,
        question_text: data.questionText ?? "(from photo)",
        solution,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);

    await awardXp(context.supabase, context.userId, "doubt_solved");
    return doubt;
  });

// ---------- Smart Revision Planner ----------

const PlanInput = z.object({
  title: z.string().min(1).max(200),
  examDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  subjects: z.array(z.string().min(1).max(100)),
  hoursPerDay: z.number(),
  notes: z.string().max(2000).optional(),
});

export const generateStudyPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PlanInput.parse(input))
  .handler(async ({ data, context }) => {
    if (data.subjects.length === 0) throw new Error("Add at least one subject.");
    const today = new Date().toISOString().slice(0, 10);
    if (data.examDate <= today) throw new Error("Exam date must be in the future.");

    const daysLeft = Math.min(
      45,
      Math.ceil((new Date(data.examDate).getTime() - Date.now()) / 86400000),
    );

    const raw = await callGateway({
      system:
        "You are an expert study planner. You output ONLY valid JSON, no prose, no code fences.",
      content: `Create a personalized daily revision timetable. Today is ${today}. Exam date: ${data.examDate}. Days available: ${daysLeft}. Subjects: ${data.subjects.join(", ")}. Study hours per day: ${Math.min(12, Math.max(1, data.hoursPerDay))}.${data.notes ? ` Extra context: ${data.notes}` : ""}
Return a JSON array of daily tasks: {"date": "YYYY-MM-DD", "subject": string (one of the given subjects), "task": string (specific, actionable goal like "Revise Chapter 3: Motion + solve 10 MCQs")}. Create 1-3 tasks per day covering every day from ${today} until the exam (max ${daysLeft} days), balancing subjects, with lighter revision + practice tests in the final days.`,
    });

    let tasks: PlanTaskInput[];
    try {
      tasks = extractJson<PlanTaskInput[]>(raw)
        .filter((t) => t?.date && t?.subject && t?.task)
        .slice(0, 120);
    } catch {
      throw new Error("The AI returned an unexpected format. Please try again.");
    }
    if (tasks.length === 0) throw new Error("Could not build a plan. Please try again.");

    const { data: plan, error } = await context.supabase
      .from("study_plans")
      .insert({
        user_id: context.userId,
        title: data.title,
        exam_date: data.examDate,
        subjects: data.subjects,
      })
      .select()
      .single();
    if (error || !plan) throw new Error(error?.message ?? "Could not create plan");

    const { error: tasksError } = await context.supabase.from("plan_tasks").insert(
      tasks.map((t) => ({
        plan_id: plan.id,
        user_id: context.userId,
        task_date: t.date,
        subject: t.subject,
        task: t.task,
      })),
    );
    if (tasksError) throw new Error(tasksError.message);

    await awardXp(context.supabase, context.userId, "plan_created");
    return plan;
  });

// ---------- Generic XP for client-side study actions ----------

const XpInput = z.object({
  reason: z.enum(["flashcard_reviewed", "task_completed"]),
});

export const awardStudyXp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => XpInput.parse(input))
  .handler(async ({ data, context }) => {
    await awardXp(context.supabase, context.userId, data.reason);
    return { ok: true };
  });
