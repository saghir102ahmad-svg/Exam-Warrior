import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export const XP_REASONS = {
  notes_generated: 20,
  quiz_completed: 30,
  flashcards_generated: 20,
  flashcard_reviewed: 2,
  doubt_solved: 10,
  plan_created: 25,
  task_completed: 5,
} as const;

export type XpReason = keyof typeof XP_REASONS;

export const XP_REASON_LABELS: Record<XpReason, string> = {
  notes_generated: "Generated notes",
  quiz_completed: "Completed a quiz",
  flashcards_generated: "Created flashcards",
  flashcard_reviewed: "Reviewed a flashcard",
  doubt_solved: "Solved a doubt",
  plan_created: "Created a study plan",
  task_completed: "Completed a study task",
};

export function levelFromXp(xp: number): number {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100)) + 1;
}

export function xpForLevel(level: number): number {
  return (level - 1) ** 2 * 100;
}

export function levelProgress(xp: number): { level: number; current: number; needed: number; pct: number } {
  const level = levelFromXp(xp);
  const base = xpForLevel(level);
  const next = xpForLevel(level + 1);
  const current = xp - base;
  const needed = next - base;
  return { level, current, needed, pct: Math.min(100, Math.round((current / needed) * 100)) };
}

export interface BadgeDef {
  key: string;
  name: string;
  emoji: string;
  description: string;
  threshold: (stats: { xp: number; streak: number; quizzes: number; notes: number; cards: number }) => boolean;
}

export const BADGES: BadgeDef[] = [
  { key: "first_steps", name: "First Steps", emoji: "👣", description: "Earn your first XP", threshold: (s) => s.xp > 0 },
  { key: "note_taker", name: "Note Taker", emoji: "📝", description: "Generate 5 sets of notes", threshold: (s) => s.notes >= 5 },
  { key: "quiz_rookie", name: "Quiz Rookie", emoji: "🎯", description: "Complete 3 quizzes", threshold: (s) => s.quizzes >= 3 },
  { key: "quiz_master", name: "Quiz Master", emoji: "🏆", description: "Complete 15 quizzes", threshold: (s) => s.quizzes >= 15 },
  { key: "card_shark", name: "Card Shark", emoji: "🃏", description: "Review 50 flashcards", threshold: (s) => s.cards >= 50 },
  { key: "on_fire", name: "On Fire", emoji: "🔥", description: "Reach a 3-day streak", threshold: (s) => s.streak >= 3 },
  { key: "unstoppable", name: "Unstoppable", emoji: "⚡", description: "Reach a 7-day streak", threshold: (s) => s.streak >= 7 },
  { key: "warrior", name: "Exam Warrior", emoji: "⚔️", description: "Reach 1,000 XP", threshold: (s) => s.xp >= 1000 },
  { key: "legend", name: "Study Legend", emoji: "👑", description: "Reach 5,000 XP", threshold: (s) => s.xp >= 5000 },
];

/** Award XP + update streak/level. Called from server function handlers with the user's RLS-scoped client. */
export async function awardXp(
  supabase: SupabaseClient<Database>,
  userId: string,
  reason: XpReason,
): Promise<void> {
  const amount = XP_REASONS[reason];
  // Use the user-scoped client to log the XP event (RLS scoped to auth.uid()).
  await supabase.from("xp_events").insert({ user_id: userId, amount, reason });

  // Profile stat columns (xp/level/streak_count/last_study_date) are protected
  // from direct user writes by a trigger — perform the update via the
  // service-role client so only server code can mutate them.
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("xp, streak_count, last_study_date")
    .eq("user_id", userId)
    .single();
  if (!profile) return;

  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  let streak = profile.streak_count;
  if (profile.last_study_date !== today) {
    streak = profile.last_study_date === yesterday ? streak + 1 : 1;
  }
  const xp = profile.xp + amount;
  await supabaseAdmin
    .from("profiles")
    .update({ xp, level: levelFromXp(xp), streak_count: streak, last_study_date: today })
    .eq("user_id", userId);
}

