import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { callGateway, embedTexts, extractJson } from "@/lib/ai-gateway.server";
import type { BookAnswer, Citation } from "@/lib/book-types";
import type { Json } from "@/integrations/supabase/types";

// ---------- Create a book record ----------

const CreateInput = z.object({
  title: z.string().min(1).max(200),
  author: z.string().max(200).optional(),
  filePath: z.string().min(1).max(400),
  pageCount: z.number().int().min(1).max(3000),
  subjectId: z.string().uuid().nullable().optional(),
});

export const createBook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: book, error } = await context.supabase
      .from("books")
      .insert({
        user_id: context.userId,
        title: data.title,
        author: data.author || null,
        file_path: data.filePath,
        page_count: data.pageCount,
        subject_id: data.subjectId ?? null,
        status: "processing",
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return book;
  });

// ---------- Index a batch of parsed chunks ----------

const ChunkSchema = z.object({
  pdfPage: z.number().int(),
  bookPage: z.number().int().nullable(),
  chapter: z.string().nullable(),
  section: z.string().nullable(),
  heading: z.string().nullable(),
  paraIndex: z.number().int(),
  lineStart: z.number().int().nullable(),
  lineEnd: z.number().int().nullable(),
  content: z.string().min(1).max(4000),
});

const IngestInput = z.object({
  bookId: z.string().uuid(),
  chunks: z.array(ChunkSchema).min(1).max(40),
});

export const ingestBookChunks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => IngestInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: book, error: bookError } = await context.supabase
      .from("books")
      .select("id")
      .eq("id", data.bookId)
      .single();
    if (bookError || !book) throw new Error("Book not found");

    const embeddings = await embedTexts(
      data.chunks.map((c) =>
        [c.chapter, c.section, c.heading, c.content].filter(Boolean).join(" — ").slice(0, 4000),
      ),
    );

    const rows = data.chunks.map((c, i) => ({
      book_id: data.bookId,
      user_id: context.userId,
      pdf_page: c.pdfPage,
      book_page: c.bookPage,
      chapter: c.chapter,
      section: c.section,
      heading: c.heading,
      para_index: c.paraIndex,
      line_start: c.lineStart,
      line_end: c.lineEnd,
      content: c.content,
      embedding: embeddings[i] ? JSON.stringify(embeddings[i]) : null,
    }));

    const { error } = await context.supabase.from("book_chunks").insert(rows);
    if (error) throw new Error(error.message);
    return { inserted: rows.length };
  });

const FinalizeInput = z.object({
  bookId: z.string().uuid(),
  status: z.enum(["ready", "failed"]),
  error: z.string().max(500).optional(),
});

export const finalizeBook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => FinalizeInput.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("books")
      .update({ status: data.status, error: data.error ?? null })
      .eq("id", data.bookId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- Ask a question about a book (retrieval + verified citations) ----------

const AskInput = z.object({
  bookId: z.string().uuid(),
  question: z.string().min(3).max(1000),
});

type RetrievedChunk = {
  id: string;
  pdf_page: number;
  book_page: number | null;
  chapter: string | null;
  section: string | null;
  heading: string | null;
  line_start: number | null;
  line_end: number | null;
  content: string;
  score: number;
};

type ModelCitation = { ref?: number; quote?: string };
type ModelAnswer = {
  found?: boolean;
  answer?: string;
  confidence?: string;
  citations?: ModelCitation[];
};

const normalize = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();

export const askBook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => AskInput.parse(input))
  .handler(async ({ data, context }): Promise<BookAnswer & { id: string | null }> => {
    const [embedding] = await embedTexts([data.question]);

    const { data: matches, error } = await context.supabase.rpc("match_book_chunks", {
      _book_id: data.bookId,
      _embedding: embedding ? JSON.stringify(embedding) : "",
      _query: data.question,
      _limit: 8,
    });
    if (error) throw new Error(error.message);

    const chunks = ((matches ?? []) as RetrievedChunk[]).filter((c) => c.content?.trim());

    const notFound: BookAnswer & { id: string | null } = {
      id: null,
      answer: "I couldn't find this information in the uploaded book.",
      found: false,
      confidence: "low",
      citations: [],
    };
    if (chunks.length === 0) return notFound;

    const contextBlock = chunks
      .map((c, i) => {
        const meta = [
          `PDF Page: ${c.pdf_page}`,
          c.book_page ? `Book Page: ${c.book_page}` : null,
          c.chapter ? `Chapter: ${c.chapter}` : null,
          c.section ? `Section: ${c.section}` : null,
          c.heading ? `Heading: ${c.heading}` : null,
          c.line_start && c.line_end ? `Lines: ${c.line_start}-${c.line_end}` : null,
        ]
          .filter(Boolean)
          .join(" | ");
        return `[${i + 1}] ${meta}\n${c.content}`;
      })
      .join("\n\n");

    const raw = await callGateway({
      system: `You are a book research assistant. You answer ONLY from the numbered passages provided by the retrieval system.
Rules:
- Never invent page numbers, chapters, sections or line numbers. Cite passages only by their [number].
- Every quote must be copied VERBATIM (character for character) from the passage you cite.
- If the passages do not contain the answer, set "found" to false.
- Prefer the single most relevant passage; add more only when they genuinely add information.
Output ONLY valid JSON, no prose and no code fences, shaped as:
{"found": boolean, "answer": string (markdown, no source list inside), "confidence": "high"|"medium"|"low", "citations": [{"ref": number, "quote": string (short verbatim excerpt, max 220 chars)}]}`,
      content: `Question: ${data.question}\n\nRetrieved passages:\n\n${contextBlock}`,
    });

    let parsed: ModelAnswer;
    try {
      parsed = extractJson<ModelAnswer>(raw);
    } catch {
      throw new Error("The AI returned an unexpected format. Please try again.");
    }

    if (!parsed.found || !parsed.answer?.trim()) return notFound;

    // Validate every citation against the retrieved passages before showing it.
    const seen = new Set<string>();
    let verifiedQuotes = 0;
    const citations: Citation[] = [];

    for (const c of parsed.citations ?? []) {
      const chunk = chunks[(c.ref ?? 0) - 1];
      if (!chunk) continue;
      const key = `${chunk.pdf_page}:${chunk.line_start}`;
      if (seen.has(key)) continue;
      seen.add(key);

      let quote: string | null = null;
      if (c.quote?.trim()) {
        const nq = normalize(c.quote);
        if (nq.length > 12 && normalize(chunk.content).includes(nq)) {
          quote = c.quote.trim().slice(0, 300);
          verifiedQuotes++;
        }
      }

      citations.push({
        pdfPage: chunk.pdf_page,
        bookPage: chunk.book_page,
        chapter: chunk.chapter,
        section: chunk.section,
        heading: chunk.heading,
        lineStart: quote ? chunk.line_start : null,
        lineEnd: quote ? chunk.line_end : null,
        quote,
      });
      if (citations.length >= 4) break;
    }

    if (citations.length === 0) return notFound;

    const confidence: BookAnswer["confidence"] =
      verifiedQuotes > 0 && citations[0].lineStart ? "high" : verifiedQuotes > 0 ? "medium" : "medium";

    const result: BookAnswer = { answer: parsed.answer.trim(), found: true, confidence, citations };

    const { data: saved } = await context.supabase
      .from("book_questions")
      .insert({
        book_id: data.bookId,
        user_id: context.userId,
        question: data.question,
        answer: result.answer,
        confidence: result.confidence,
        citations: result.citations as unknown as Json,
      })
      .select("id")
      .single();

    return { ...result, id: saved?.id ?? null };
  });
