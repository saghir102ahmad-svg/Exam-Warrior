export interface McqQuestion {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface FlashcardInput {
  front: string;
  back: string;
}

export interface PlanTaskInput {
  date: string;
  subject: string;
  task: string;
}

export const DOUBT_SUBJECTS = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer Science",
  "English",
] as const;

export const SUBJECT_COLORS = ["violet", "cyan", "emerald", "amber", "rose", "blue"] as const;

export function subjectColorVar(color: string): string {
  return `var(--subject-${SUBJECT_COLORS.includes(color as (typeof SUBJECT_COLORS)[number]) ? color : "violet"})`;
}

export const MOTIVATION_QUOTES = [
  "Success is the sum of small efforts, repeated day in and day out.",
  "The expert in anything was once a beginner.",
  "Don't watch the clock; do what it does. Keep going.",
  "Your future is created by what you do today, not tomorrow.",
  "Push yourself, because no one else is going to do it for you.",
  "It always seems impossible until it's done.",
  "Study now, shine later.",
  "Discipline beats motivation every single time.",
  "One chapter a day keeps exam fear away.",
  "Winners are not people who never fail, but people who never quit.",
  "The pain of studying is temporary. The pride of results lasts forever.",
  "Small progress is still progress.",
  "You don't have to be great to start, but you have to start to be great.",
  "Dream big. Study hard. Stay focused.",
];

export function todaysQuote(): string {
  const day = Math.floor(Date.now() / 86400000);
  return MOTIVATION_QUOTES[day % MOTIVATION_QUOTES.length];
}
