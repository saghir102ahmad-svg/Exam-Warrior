import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

const BASE_URL = "https://ai.gateway.lovable.dev/v1";

export function createLovableAiGatewayProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "lovable-ai",
    baseURL: BASE_URL,
    headers: { "Lovable-API-Key": apiKey },
  });
}

export type GatewayBlock =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };

/** Raw chat-completions call (supports multimodal image input). Returns the text content. */
export async function callGateway(opts: {
  system?: string;
  content: string | GatewayBlock[];
  model?: string;
}): Promise<string> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("AI is not configured for this project.");

  const res = await fetch(`${BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": key,
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: opts.model ?? "google/gemini-3-flash-preview",
      messages: [
        ...(opts.system ? [{ role: "system", content: opts.system }] : []),
        { role: "user", content: opts.content },
      ],
    }),
  });

  if (res.status === 429) throw new Error("AI rate limit reached — please try again in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted — please add credits to your workspace.");
  if (!res.ok) {
    const body = await res.text();
    console.error(`AI gateway error [${res.status}]: ${body}`);
    throw new Error(`AI request failed (${res.status}). Please try again.`);
  }

  const data = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  return data.choices?.[0]?.message?.content ?? "";
}

/** Embed a batch of texts (768-dim) through the Lovable AI gateway. */
export async function embedTexts(texts: string[]): Promise<number[][]> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("AI is not configured for this project.");

  const res = await fetch(`${BASE_URL}/embeddings`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": key,
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "google/gemini-embedding-001",
      input: texts,
      dimensions: 768,
    }),
  });

  if (res.status === 429) throw new Error("AI rate limit reached — please try again in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted — please add credits to your workspace.");
  if (!res.ok) {
    const body = await res.text();
    console.error(`AI embeddings error [${res.status}]: ${body}`);
    throw new Error(`Could not index this text (${res.status}). Please try again.`);
  }

  const data = (await res.json()) as { data?: Array<{ embedding: number[]; index?: number }> };
  const rows = data.data ?? [];
  return rows
    .slice()
    .sort((a, b) => (a.index ?? 0) - (b.index ?? 0))
    .map((r) => r.embedding);
}

/** Extract a JSON object/array from a model response that may include code fences or prose. */
export function extractJson<T>(text: string): T {
  const cleaned = text.replace(/```(?:json)?/gi, "").trim();
  const firstBrace = cleaned.indexOf("{");
  const firstBracket = cleaned.indexOf("[");
  const candidates = [firstBrace, firstBracket].filter((i) => i !== -1);
  if (candidates.length === 0) throw new Error("AI returned an unexpected format. Please try again.");
  const start = Math.min(...candidates);
  const end = Math.max(cleaned.lastIndexOf("}"), cleaned.lastIndexOf("]"));
  return JSON.parse(cleaned.slice(start, end + 1)) as T;
}
