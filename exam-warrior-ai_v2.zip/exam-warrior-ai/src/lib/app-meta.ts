export const APP_META = {
  name: "Exam Warrior AI",
  tagline: "AI-Powered Study App for Students",
  version: "1.0.0",
  description:
    "Exam Warrior AI is an all-in-one AI-powered study platform for school, college, and university students. Generate notes, take MCQ quizzes, revise with flashcards, snap doubts for step-by-step solutions, plan your revision, and stay motivated with XP, streaks and leaderboards.",
  mission:
    "To make quality exam preparation accessible to every student — regardless of background — through AI tutoring, smart practice and gamified daily study habits.",
  developer: "Exam Warrior AI Team",
  contactEmail: "support@examwarrior.ai",
  website: "https://examwarrior.ai",
  socials: {
    youtube: "https://youtube.com/@examwarriorai",
    instagram: "https://instagram.com/examwarriorai",
    facebook: "https://facebook.com/examwarriorai",
    twitter: "https://x.com/examwarriorai",
  },
  copyright: `© ${new Date().getFullYear()} Exam Warrior AI. All rights reserved.`,
};

export const FEATURES_LIST = [
  "AI Notes Generator (English & Urdu)",
  "AI MCQ Generator with Easy/Medium/Hard difficulty",
  "Smart Flashcards with spaced repetition",
  "DoubtSnap AI — photo/text step-by-step solver",
  "24/7 AI Study Assistant chatbot",
  "AI Revision Planner with exam countdown",
  "Weak Topic Analyzer",
  "XP, levels, streaks & achievement badges",
  "Global leaderboard",
  "Subject & chapter management",
  "Progress dashboard with charts",
];
