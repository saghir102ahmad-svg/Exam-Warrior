import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useRoles() {
  return useQuery({
    queryKey: ["roles"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return { isAdmin: false, isModerator: false, roles: [] as string[] };
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
      const roles = (data ?? []).map((r) => r.role as string);
      return {
        roles,
        isAdmin: roles.includes("admin"),
        isModerator: roles.includes("admin") || roles.includes("moderator"),
      };
    },
  });
}

export function useAnyAdminExists() {
  return useQuery({
    queryKey: ["any-admin-exists"],
    queryFn: async () => {
      const { count } = await supabase
        .from("user_roles")
        .select("id", { count: "exact", head: true })
        .eq("role", "admin");
      return (count ?? 0) > 0;
    },
  });
}
