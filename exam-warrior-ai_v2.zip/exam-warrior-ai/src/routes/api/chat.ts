import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import type { Database } from "@/integrations/supabase/types";

type ChatRequestBody = { messages?: unknown };

const SYSTEM_PROMPT = `You are the Exam Warrior AI Study Assistant — a friendly, encouraging 24/7 tutor for school, college and university students.
- Answer academic questions accurately across Mathematics, Physics, Chemistry, Biology, Computer Science, English and more.
- Explain concepts simply, with analogies and examples.
- When helpful, generate practice questions and short quizzes.
- Format answers with markdown: headings, bullet points, **bold key terms**.
- Keep answers focused and student-friendly. If asked in Urdu, reply in Urdu.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authHeader = request.headers.get("authorization");
        if (!authHeader?.startsWith("Bearer ")) {
          return new Response("Unauthorized", { status: 401 });
        }
        const token = authHeader.slice(7).trim();
        if (!token || token.split(".").length !== 3) {
          return new Response("Unauthorized", { status: 401 });
        }

        const supabaseUrl = process.env.SUPABASE_URL;
        const supabasePublishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
        if (!supabaseUrl || !supabasePublishableKey) {
          return new Response("Server misconfigured", { status: 500 });
        }
        const supabase = createClient<Database>(supabaseUrl, supabasePublishableKey, {
          auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        });
        const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
        if (claimsError || !claimsData?.claims?.sub) {
          return new Response("Unauthorized", { status: 401 });
        }

        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        const userId = claimsData.claims.sub;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Persist the latest user message
        const last = (messages as UIMessage[])[messages.length - 1];
        if (last?.role === "user") {
          const text = last.parts.map((p: any) => (p.type === "text" ? p.text : "")).join("").trim();
          if (text) {
            await supabaseAdmin.from("chat_messages").insert({ user_id: userId, role: "user", content: text.slice(0, 8000) });
          }
        }

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system: SYSTEM_PROMPT,
          messages: await convertToModelMessages(messages as UIMessage[]),
          onFinish: async ({ text }) => {
            if (text?.trim()) {
              await supabaseAdmin.from("chat_messages").insert({
                user_id: userId,
                role: "assistant",
                content: text.slice(0, 16000),
              });
            }
          },
        });

        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});
