import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { BookOpen, Upload, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { createBook, ingestBookChunks, finalizeBook } from "@/lib/books.functions";

export const Route = createFileRoute("/_authenticated/books/")({
  head: () => ({
    meta: [
      { title: "Books — Exam Warrior AI" },
      { name: "description", content: "Upload textbooks and ask questions with verified page citations." },
    ],
  }),
  component: BooksPage,
});

function BooksPage() {
  const qc = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [progress, setProgress] = useState<{ label: string; pct: number } | null>(null);

  const { data: books } = useQuery({
    queryKey: ["books"],
    queryFn: async () => {
      const { data } = await supabase.from("books").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function upload() {
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) return toast.error("Max file size is 50 MB");
    let bookId: string | null = null;
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Please sign in");
      setProgress({ label: "Reading PDF…", pct: 0 });
      const { parsePdf, buildChunks } = await import("@/lib/pdf-parse");
      const { pages, pageCount } = await parsePdf(file, (p, t) =>
        setProgress({ label: `Reading page ${p}/${t}`, pct: (p / t) * 30 }),
      );
      const chunks = buildChunks(pages);
      if (!chunks.length) throw new Error("No readable text found (scanned PDFs aren't supported yet).");

      const path = `${u.user.id}/${crypto.randomUUID()}.pdf`;
      setProgress({ label: "Uploading…", pct: 32 });
      const { error: upErr } = await supabase.storage.from("books").upload(path, file, { contentType: "application/pdf" });
      if (upErr) throw upErr;

      const book = await createBook({
        data: { title: title.trim() || file.name.replace(/\.pdf$/i, ""), filePath: path, pageCount },
      });
      bookId = book.id;
      for (let i = 0; i < chunks.length; i += 40) {
        await ingestBookChunks({ data: { bookId: book.id, chunks: chunks.slice(i, i + 40) } });
        setProgress({ label: `Indexing ${Math.min(i + 40, chunks.length)}/${chunks.length}`, pct: 35 + ((i + 40) / chunks.length) * 65 });
      }
      await finalizeBook({ data: { bookId: book.id, status: "ready" } });
      toast.success("Book ready! Ask it anything.");
      setFile(null);
      setTitle("");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Upload failed";
      if (bookId) await finalizeBook({ data: { bookId, status: "failed", error: msg.slice(0, 500) } }).catch(() => {});
      toast.error(msg);
    } finally {
      setProgress(null);
      qc.invalidateQueries({ queryKey: ["books"] });
    }
  }

  async function remove(id: string, path: string) {
    if (!confirm("Delete this book?")) return;
    await supabase.storage.from("books").remove([path]);
    await supabase.from("books").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["books"] });
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <h1 className="flex items-center gap-2 font-display text-3xl font-bold">
          <BookOpen className="h-7 w-7 text-primary" />
          Books
        </h1>
        <p className="text-sm text-muted-foreground">Upload a PDF and ask questions — every answer shows the exact page.</p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-4">
          <Input placeholder="Book title (optional)" value={title} onChange={(e) => setTitle(e.target.value)} disabled={!!progress} />
          <Input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} disabled={!!progress} />
          {progress && (
            <div className="space-y-1">
              <Progress value={progress.pct} />
              <p className="text-xs text-muted-foreground">{progress.label}</p>
            </div>
          )}
          <Button onClick={upload} disabled={!file || !!progress}>
            {progress ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
            Upload & index
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        {(books ?? []).map((b) => (
          <Card key={b.id}>
            <CardContent className="flex items-start justify-between gap-3 p-4">
              <div className="min-w-0">
                {b.status === "ready" ? (
                  <Link to="/books/$bookId" params={{ bookId: b.id }} className="font-semibold hover:text-primary">
                    {b.title}
                  </Link>
                ) : (
                  <span className="font-semibold">{b.title}</span>
                )}
                <p className="text-xs text-muted-foreground">
                  {b.page_count} pages · {b.status === "ready" ? "Ready" : b.status === "failed" ? `Failed: ${b.error ?? ""}` : "Processing…"}
                </p>
              </div>
              <Button size="icon" variant="ghost" onClick={() => remove(b.id, b.file_path)} aria-label="Delete book">
                <Trash2 className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
        {books?.length === 0 && <p className="text-sm text-muted-foreground">No books yet.</p>}
      </div>
    </div>
  );
}
