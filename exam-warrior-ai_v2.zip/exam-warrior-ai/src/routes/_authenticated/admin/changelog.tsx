import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { upsertChangelog, deleteChangelog } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/admin/changelog")({
  component: AdminChangelog,
});

function AdminChangelog() {
  const qc = useQueryClient();
  const [version, setVersion] = useState("");
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");

  const upsert = useServerFn(upsertChangelog);
  const del = useServerFn(deleteChangelog);

  const { data } = useQuery({
    queryKey: ["changelog-admin"],
    queryFn: async () => (await supabase.from("app_changelog").select("*").order("released_at", { ascending: false })).data ?? [],
  });

  const create = useMutation({
    mutationFn: () => upsert({ data: { version, title, notes } }),
    onSuccess: () => {
      toast.success("Added");
      setVersion(""); setTitle(""); setNotes("");
      qc.invalidateQueries({ queryKey: ["changelog-admin"] });
      qc.invalidateQueries({ queryKey: ["changelog-public"] });
    },
    onError: (e: any) => toast.error(e.message),
  });
  const remove = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["changelog-admin"] }); qc.invalidateQueries({ queryKey: ["changelog-public"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-5 space-y-3">
          <h2 className="font-display text-lg font-bold">Add changelog entry</h2>
          <Input placeholder="Version (e.g. 1.1.0)" value={version} onChange={(e) => setVersion(e.target.value)} />
          <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Textarea rows={4} placeholder="Release notes..." value={notes} onChange={(e) => setNotes(e.target.value)} />
          <div className="flex justify-end">
            <Button onClick={() => create.mutate()} disabled={!version || !title || !notes}>Add</Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {(data ?? []).map((e: any) => (
          <Card key={e.id}>
            <CardContent className="p-4 flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="font-semibold">v{e.version} — {e.title}</div>
                <p className="mt-1 text-sm text-muted-foreground whitespace-pre-line">{e.notes}</p>
                <div className="mt-1 text-xs text-muted-foreground">{new Date(e.released_at).toLocaleDateString()} {e.is_published ? "" : "• draft"}</div>
              </div>
              <Button size="sm" variant="destructive" onClick={() => { if (confirm("Delete this entry?")) remove.mutate(e.id); }}><Trash2 className="h-3.5 w-3.5" /></Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
