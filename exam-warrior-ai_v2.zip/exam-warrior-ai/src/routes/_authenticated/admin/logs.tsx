import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAdminLogs } from "@/lib/admin.functions";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/logs")({
  component: AdminLogs,
});

function AdminLogs() {
  const listFn = useServerFn(listAdminLogs);
  const { data } = useQuery({
    queryKey: ["admin-logs"],
    queryFn: () => listFn({ data: { limit: 300 } }),
  });

  return (
    <div className="space-y-2">
      {(data?.rows ?? []).map((l: any) => (
        <Card key={l.id}>
          <CardContent className="p-3 text-sm">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <div>
                <span className="font-mono text-xs text-muted-foreground">{l.admin_user_id.slice(0, 8)}</span>
                <span className="ml-2 font-semibold">{l.action}</span>
                {l.target_type && <span className="ml-2 text-muted-foreground">→ {l.target_type} {l.target_id?.slice(0, 8)}</span>}
              </div>
              <span className="text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString()}</span>
            </div>
            {l.details && <pre className="mt-1 text-xs text-muted-foreground overflow-x-auto">{JSON.stringify(l.details, null, 0)}</pre>}
          </CardContent>
        </Card>
      ))}
      {data?.rows.length === 0 && <p className="text-sm text-muted-foreground">No activity yet.</p>}
    </div>
  );
}
