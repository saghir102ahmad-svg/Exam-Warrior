import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Users, UserCheck, UserX, TrendingUp, FileText, Target, Camera, Zap } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent } from "@/components/ui/card";
import { getAdminStats } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminOverview,
});

function AdminOverview() {
  const fetchStats = useServerFn(getAdminStats);
  const { data, isLoading } = useQuery({ queryKey: ["admin-stats"], queryFn: () => fetchStats() });

  if (isLoading || !data) return <p className="text-sm text-muted-foreground">Loading stats...</p>;

  const stats = [
    { label: "Total users", value: data.totalUsers, icon: Users, color: "text-primary" },
    { label: "Active (7d)", value: data.activeUsers, icon: UserCheck, color: "text-emerald-400" },
    { label: "Banned", value: data.banned, icon: UserX, color: "text-red-400" },
    { label: "New (24h)", value: data.last24h, icon: TrendingUp, color: "text-gold" },
    { label: "New (7d)", value: data.last7d, icon: TrendingUp, color: "text-gold" },
    { label: "New (30d)", value: data.last30d, icon: TrendingUp, color: "text-gold" },
    { label: "Notes", value: data.notes, icon: FileText, color: "text-primary" },
    { label: "Quizzes", value: data.quizzes, icon: Target, color: "text-primary" },
    { label: "Doubts", value: data.doubts, icon: Camera, color: "text-primary" },
    { label: "XP awarded (7d)", value: data.xpAwardedThisWeek, icon: Zap, color: "text-gold" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-3 grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{s.label}</span>
                <s.icon className={`h-4 w-4 ${s.color}`} />
              </div>
              <div className="mt-2 font-display text-2xl font-bold">{s.value.toLocaleString()}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-5">
          <h2 className="font-display text-lg font-bold mb-3">Signups (last 14 days)</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer>
              <LineChart data={data.signupBuckets}>
                <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => d.slice(5)} />
                <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
