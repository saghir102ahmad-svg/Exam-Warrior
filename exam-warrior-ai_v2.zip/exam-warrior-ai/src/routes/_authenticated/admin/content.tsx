import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { listAdminContent, deleteAdminContent } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/content")({
  component: AdminContent,
});

type Table = "notes" | "quizzes" | "doubts";

function AdminContent() {
  const [table, setTable] = useState<Table>("notes");
  const qc = useQueryClient();
  const listFn = useServerFn(listAdminContent);
  const delFn = useServerFn(deleteAdminContent);

  const { data } = useQuery({
    queryKey: ["admin-content", table],
    queryFn: () => listFn({ data: { table, limit: 200 } }),
  });

  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { table, id } }),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-content"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {(["notes", "quizzes", "doubts"] as Table[]).map((t) => (
          <Button key={t} size="sm" variant={table === t ? "default" : "outline"} onClick={() => setTable(t)}>{t}</Button>
        ))}
      </div>

      <div className="space-y-2">
        {(data?.rows ?? []).map((r: any) => (
          <Card key={r.id}>
            <CardContent className="p-4 flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium">
                  {r.title ?? r.question ?? "(no title)"}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {r.difficulty && <>diff: {r.difficulty} • </>}
                  {r.language && <>lang: {r.language} • </>}
                  user: <span className="font-mono">{r.user_id.slice(0, 8)}</span> • {new Date(r.created_at).toLocaleString()}
                </div>
              </div>
              <Button size="sm" variant="destructive" onClick={() => { if (confirm("Delete this item?")) del.mutate(r.id); }}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        ))}
        {data?.rows.length === 0 && <p className="text-sm text-muted-foreground">Nothing here.</p>}
      </div>
    </div>
  );
}
