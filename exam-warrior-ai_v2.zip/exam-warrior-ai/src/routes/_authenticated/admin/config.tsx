import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Save, AlertTriangle } from "lucide-react";
import { getAppConfig, updateAppConfig } from "@/lib/admin.functions";
import { APP_META } from "@/lib/app-meta";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/admin/config")({
  component: AdminConfig,
});

function AdminConfig() {
  const getCfg = useServerFn(getAppConfig);
  const updCfg = useServerFn(updateAppConfig);
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["admin-app-config"], queryFn: () => getCfg() });

  const [form, setForm] = useState({
    current_version: "",
    min_required_version: "",
    update_url: "",
    update_message: "",
    force_update: false,
  });

  useEffect(() => {
    if (data) {
      setForm({
        current_version: data.current_version ?? "",
        min_required_version: data.min_required_version ?? "",
        update_url: data.update_url ?? "",
        update_message: data.update_message ?? "",
        force_update: data.force_update ?? false,
      });
    }
  }, [data]);

  const save = useMutation({
    mutationFn: () => updCfg({ data: { ...form, update_url: form.update_url || null } }),
    onSuccess: () => {
      toast.success("Saved. Users will see the update prompt on next load.");
      qc.invalidateQueries({ queryKey: ["admin-app-config"] });
      qc.invalidateQueries({ queryKey: ["app-config"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-4 max-w-2xl">
      <Card>
        <CardContent className="p-5 space-y-4">
          <div>
            <h2 className="font-display text-lg font-bold">App version & force update</h2>
            <p className="text-xs text-muted-foreground mt-1">
              This app is currently running <span className="font-mono">{APP_META.version}</span>. Set a minimum required version and enable force update to block older versions.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold">Latest available version</label>
              <Input value={form.current_version} onChange={(e) => setForm({ ...form, current_version: e.target.value })} placeholder="1.2.0" />
            </div>
            <div>
              <label className="text-xs font-semibold">Minimum required version</label>
              <Input value={form.min_required_version} onChange={(e) => setForm({ ...form, min_required_version: e.target.value })} placeholder="1.0.0" />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold">Update URL (Play Store / App Store / download link)</label>
            <Input value={form.update_url} onChange={(e) => setForm({ ...form, update_url: e.target.value })} placeholder="https://..." />
          </div>

          <div>
            <label className="text-xs font-semibold">Message shown to users</label>
            <Textarea value={form.update_message} onChange={(e) => setForm({ ...form, update_message: e.target.value })} rows={3} />
          </div>

          <label className="flex items-start gap-3 rounded-lg border border-border p-3 cursor-pointer">
            <input
              type="checkbox"
              checked={form.force_update}
              onChange={(e) => setForm({ ...form, force_update: e.target.checked })}
              className="mt-0.5 h-4 w-4"
            />
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold">
                <AlertTriangle className="h-4 w-4 text-destructive" /> Force update
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                When enabled, any user on a version below the minimum required version will be blocked from using the app until they update.
              </p>
            </div>
          </label>

          <Button variant="hero" onClick={() => save.mutate()} disabled={save.isPending}>
            <Save className="h-4 w-4" /> {save.isPending ? "Saving..." : "Save"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
