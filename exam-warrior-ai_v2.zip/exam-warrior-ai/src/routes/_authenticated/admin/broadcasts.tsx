import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sendBroadcast } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";

export const Route = createFileRoute("/_authenticated/admin/broadcasts")({
  component: BroadcastsPage,
});

function BroadcastsPage() {
  const qc = useQueryClient();
  const send = useServerFn(sendBroadcast);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [target, setTarget] = useState("all");

  const { data } = useQuery({
    queryKey: ["broadcasts-admin"],
    queryFn: async () => {
      const { data } = await supabase.from("broadcast_notifications").select("*").order("published_at", { ascending: false }).limit(50);
      return data ?? [];
    },
  });

  const sendM = useMutation({
    mutationFn: () => send({ data: { title, message, target } }),
    onSuccess: () => {
      toast.success("Broadcast sent");
      setTitle(""); setMessage("");
      qc.invalidateQueries({ queryKey: ["broadcasts-admin"] });
      qc.invalidateQueries({ queryKey: ["broadcasts"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-5 space-y-3">
          <h2 className="font-display text-lg font-bold">Send broadcast</h2>
          <SelectNative value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="all">All users</option>
            <option value="school">School students</option>
            <option value="college">College students</option>
            <option value="university">University students</option>
          </SelectNative>
          <Input placeholder="Title" maxLength={200} value={title} onChange={(e) => setTitle(e.target.value)} />
          <Textarea rows={4} placeholder="Message..." maxLength={2000} value={message} onChange={(e) => setMessage(e.target.value)} />
          <div className="flex justify-end">
            <Button onClick={() => sendM.mutate()} disabled={sendM.isPending || !title.trim() || !message.trim()}>{sendM.isPending ? "Sending..." : "Send"}</Button>
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="font-display text-lg font-bold mb-3">History</h2>
        <div className="space-y-2">
          {(data ?? []).map((b: any) => (
            <Card key={b.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div className="font-semibold">{b.title}</div>
                  <span className="text-xs text-muted-foreground">{new Date(b.published_at).toLocaleString()}</span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground whitespace-pre-line">{b.message}</p>
                <span className="mt-1 inline-block rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase">{b.target}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
