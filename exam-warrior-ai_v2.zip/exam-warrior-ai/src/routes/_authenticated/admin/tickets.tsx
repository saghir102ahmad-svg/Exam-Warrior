import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listAdminTickets, updateAdminTicket } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";

export const Route = createFileRoute("/_authenticated/admin/tickets")({
  component: AdminTickets,
});

function AdminTickets() {
  const [status, setStatus] = useState("");
  const qc = useQueryClient();
  const listFn = useServerFn(listAdminTickets);
  const updateFn = useServerFn(updateAdminTicket);
  const [replies, setReplies] = useState<Record<string, string>>({});

  const { data } = useQuery({
    queryKey: ["admin-tickets", status],
    queryFn: () => listFn({ data: { status: status || undefined } }),
  });

  const update = useMutation({
    mutationFn: (v: { id: string; status?: string; admin_reply?: string }) => updateFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-tickets"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <SelectNative value={status} onChange={(e) => setStatus(e.target.value)} className="max-w-xs">
        <option value="">All</option>
        <option value="open">Open</option>
        <option value="in_progress">In progress</option>
        <option value="closed">Closed</option>
      </SelectNative>

      <div className="space-y-3">
        {(data?.rows ?? []).map((t: any) => (
          <Card key={t.id}>
            <CardContent className="p-4 space-y-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="font-semibold">{t.subject} <span className="ml-2 text-xs text-muted-foreground">[{t.category}]</span></div>
                <SelectNative value={t.status} onChange={(e) => update.mutate({ id: t.id, status: e.target.value })} className="w-40">
                  <option value="open">Open</option>
                  <option value="in_progress">In progress</option>
                  <option value="closed">Closed</option>
                </SelectNative>
              </div>
              <p className="text-sm text-muted-foreground whitespace-pre-line">{t.message}</p>
              <div className="text-xs text-muted-foreground">User: <span className="font-mono">{t.user_id.slice(0, 8)}</span> • {new Date(t.created_at).toLocaleString()}</div>
              {t.admin_reply && (
                <div className="rounded-md bg-primary/10 border border-primary/20 p-3 text-sm">
                  <div className="text-xs font-semibold text-primary mb-1">Your reply</div>
                  <div className="whitespace-pre-line">{t.admin_reply}</div>
                </div>
              )}
              <div className="flex gap-2">
                <Textarea
                  rows={2}
                  placeholder="Reply to user..."
                  value={replies[t.id] ?? ""}
                  onChange={(e) => setReplies({ ...replies, [t.id]: e.target.value })}
                />
                <Button size="sm" onClick={() => { if (replies[t.id]?.trim()) { update.mutate({ id: t.id, admin_reply: replies[t.id].trim(), status: "in_progress" }); setReplies({ ...replies, [t.id]: "" }); } }}>Reply</Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {data?.rows.length === 0 && <p className="text-sm text-muted-foreground">No tickets.</p>}
      </div>
    </div>
  );
}
