import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { MessageCircle, Search, User as UserIcon } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { listChatUsers, getUserChat } from "@/lib/admin.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/chats")({
  component: AdminChats,
});

function AdminChats() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);

  const listFn = useServerFn(listChatUsers);
  const chatFn = useServerFn(getUserChat);

  const { data: users } = useQuery({
    queryKey: ["admin-chat-users", search],
    queryFn: () => listFn({ data: { search } }),
  });

  const { data: chat } = useQuery({
    queryKey: ["admin-chat", selected],
    queryFn: () => chatFn({ data: { userId: selected! } }),
    enabled: !!selected,
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search users..." className="pl-9" />
        </div>
        <div className="space-y-1.5 max-h-[70vh] overflow-y-auto">
          {(users?.users ?? []).map((u: any) => (
            <button
              key={u.user_id}
              onClick={() => setSelected(u.user_id)}
              className={cn(
                "w-full text-left flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm transition-colors",
                selected === u.user_id ? "bg-primary/15 border-primary/40" : "bg-card hover:bg-secondary"
              )}
            >
              <UserIcon className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium">{u.display_name || "Student"}</div>
                <div className="text-[10px] text-muted-foreground">
                  {u.last_message_at ? new Date(u.last_message_at).toLocaleString() : ""}
                </div>
              </div>
            </button>
          ))}
          {users && users.users.length === 0 && (
            <p className="text-sm text-muted-foreground p-2">No chats yet.</p>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          {!selected ? (
            <div className="text-center text-muted-foreground py-16">
              <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Select a user to view their AI chat</p>
            </div>
          ) : !chat ? (
            <p className="text-sm text-muted-foreground">Loading...</p>
          ) : (
            <div className="space-y-3">
              <h2 className="font-display font-bold">{chat.displayName}'s AI conversation</h2>
              <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-2">
                {chat.messages.map((m: any) => (
                  <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                    <div
                      className={cn(
                        "max-w-[85%] rounded-2xl px-3 py-2 text-sm",
                        m.role === "user" ? "bg-primary text-primary-foreground" : "border border-border bg-card"
                      )}
                    >
                      {m.role === "user" ? (
                        <span className="whitespace-pre-wrap">{m.content}</span>
                      ) : (
                        <div className="prose-notes text-sm">
                          <ReactMarkdown>{m.content}</ReactMarkdown>
                        </div>
                      )}
                      <div className="mt-1 text-[10px] opacity-60">{new Date(m.created_at).toLocaleString()}</div>
                    </div>
                  </div>
                ))}
                {chat.messages.length === 0 && <p className="text-sm text-muted-foreground">No messages yet.</p>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
