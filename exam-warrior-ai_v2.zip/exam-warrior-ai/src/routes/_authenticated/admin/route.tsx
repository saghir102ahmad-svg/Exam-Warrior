import { createFileRoute, Link, Outlet, useRouterState, redirect } from "@tanstack/react-router";
import { LayoutDashboard, Users, FileWarning, Megaphone, LifeBuoy, ScrollText, History, ArrowLeft, Settings, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  ssr: false,
  beforeLoad: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw redirect({ to: "/auth" });
    const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
    const roles = (data ?? []).map((r) => r.role);
    if (!roles.includes("admin") && !roles.includes("moderator")) {
      throw redirect({ to: "/dashboard" });
    }
    return { adminRoles: roles };
  },
  component: AdminLayout,
});

const NAV = [
  { to: "/admin", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/chats", label: "User chats", icon: MessageCircle },
  { to: "/admin/content", label: "Content", icon: FileWarning },
  { to: "/admin/broadcasts", label: "Broadcasts", icon: Megaphone },
  { to: "/admin/tickets", label: "Support", icon: LifeBuoy },
  { to: "/admin/changelog", label: "Changelog", icon: ScrollText },
  { to: "/admin/config", label: "App config", icon: Settings },
  { to: "/admin/logs", label: "Activity logs", icon: History },
];

function AdminLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Link to="/dashboard" className="flex items-center gap-1 hover:text-foreground"><ArrowLeft className="h-3 w-3" />Back to app</Link>
          </div>
          <h1 className="font-display text-3xl font-bold mt-1">Admin Panel</h1>
        </div>
      </div>

      <nav className="flex gap-1 overflow-x-auto border-b border-border pb-2">
        {NAV.map((n) => {
          const active = n.exact ? pathname === n.to : pathname.startsWith(n.to);
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <n.icon className="h-4 w-4" />{n.label}
            </Link>
          );
        })}
      </nav>

      <Outlet />
    </div>
  );
}
