import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Search, Ban, ShieldCheck, Trash2, ShieldPlus, ShieldMinus, LogOut } from "lucide-react";
import { toast } from "sonner";
import { listAdminUsers, setUserBan, deleteUserFn, setUserRole, kickUser } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: AdminUsers,
});

function AdminUsers() {
  const [search, setSearch] = useState("");
  const qc = useQueryClient();

  const list = useServerFn(listAdminUsers);
  const banFn = useServerFn(setUserBan);
  const delFn = useServerFn(deleteUserFn);
  const roleFn = useServerFn(setUserRole);
  const kickFn = useServerFn(kickUser);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users", search],
    queryFn: () => list({ data: { search, limit: 100 } }),
  });

  const banM = useMutation({
    mutationFn: (v: { userId: string; banned: boolean }) => banFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const delM = useMutation({
    mutationFn: (userId: string) => delFn({ data: { userId } }),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const roleM = useMutation({
    mutationFn: (v: { userId: string; role: "admin" | "moderator"; enabled: boolean }) => roleFn({ data: v }),
    onSuccess: () => { toast.success("Role updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const kickM = useMutation({
    mutationFn: (userId: string) => kickFn({ data: { userId } }),
    onSuccess: () => toast.success("User signed out from all devices"),
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by display name..." className="pl-9" />
        </div>
        <span className="text-sm text-muted-foreground">Total: {data?.total ?? 0}</span>
      </div>

      {isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}

      <div className="space-y-2">
        {(data?.users ?? []).map((u: any) => (
          <Card key={u.user_id}>
            <CardContent className="p-4">
              <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_auto] items-center">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold">{u.display_name || "Student"}</span>
                    {u.roles.includes("admin") && <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-bold uppercase text-primary">Admin</span>}
                    {u.roles.includes("moderator") && <span className="rounded-full bg-gold/20 px-2 py-0.5 text-[10px] font-bold uppercase text-gold">Mod</span>}
                    {u.is_banned && <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-bold uppercase text-red-400">Banned</span>}
                  </div>
                  <div className="mt-1 truncate text-xs text-muted-foreground">{u.email}</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {u.education_level ?? "—"} • {u.language ?? "en"} • L{u.level} • {u.xp} XP • 🔥 {u.streak_count} • joined {new Date(u.created_at).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 justify-end">
                  <Button size="sm" variant={u.is_banned ? "secondary" : "outline"} onClick={() => banM.mutate({ userId: u.user_id, banned: !u.is_banned })}>
                    {u.is_banned ? <><ShieldCheck className="h-3.5 w-3.5 mr-1" />Unban</> : <><Ban className="h-3.5 w-3.5 mr-1" />Ban</>}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => kickM.mutate(u.user_id)} title="Sign user out from all devices">
                    <LogOut className="h-3.5 w-3.5 mr-1" />Kick
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => roleM.mutate({ userId: u.user_id, role: "moderator", enabled: !u.roles.includes("moderator") })}>
                    {u.roles.includes("moderator") ? <ShieldMinus className="h-3.5 w-3.5" /> : <ShieldPlus className="h-3.5 w-3.5" />}
                    <span className="ml-1">Mod</span>
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => roleM.mutate({ userId: u.user_id, role: "admin", enabled: !u.roles.includes("admin") })}>
                    {u.roles.includes("admin") ? <ShieldMinus className="h-3.5 w-3.5" /> : <ShieldPlus className="h-3.5 w-3.5" />}
                    <span className="ml-1">Admin</span>
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => { if (confirm(`Delete ${u.display_name}? This is permanent.`)) delM.mutate(u.user_id); }}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
