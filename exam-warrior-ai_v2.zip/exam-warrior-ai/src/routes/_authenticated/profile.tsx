import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { LogOut, Save, Shield, ShieldCheck, HelpCircle, MessageSquare, Bell, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/hooks/useProfile";
import { useRoles, useAnyAdminExists } from "@/hooks/useRoles";
import { BADGES, levelProgress } from "@/lib/xp";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SelectNative } from "@/components/ui/select-native";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const { data: roles } = useRoles();
  const { data: anyAdmin } = useAnyAdminExists();

  const [displayName, setDisplayName] = useState("");
  const [educationLevel, setEducationLevel] = useState("school");
  const [language, setLanguage] = useState("english");

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name);
      setEducationLevel(profile.education_level);
      setLanguage(profile.language);
    }
  }, [profile]);

  const { data: counts } = useQuery({
    queryKey: ["profile-counts"],
    queryFn: async () => {
      const [quizzes, notes, reviews] = await Promise.all([
        supabase.from("quiz_attempts").select("id", { count: "exact", head: true }),
        supabase.from("notes").select("id", { count: "exact", head: true }),
        supabase.from("xp_events").select("id", { count: "exact", head: true }).eq("reason", "flashcard_reviewed"),
      ]);
      return { quizzes: quizzes.count ?? 0, notes: notes.count ?? 0, cards: reviews.count ?? 0 };
    },
  });

  async function saveProfile() {
    if (!profile) return;
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName, education_level: educationLevel, language })
      .eq("user_id", profile.user_id);
    if (error) {
      toast.error(error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["profile"] });
    toast.success("Profile saved!");
  }

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const stats = {
    xp: profile?.xp ?? 0,
    streak: profile?.streak_count ?? 0,
    quizzes: counts?.quizzes ?? 0,
    notes: counts?.notes ?? 0,
    cards: counts?.cards ?? 0,
  };
  const lp = levelProgress(stats.xp);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl gradient-primary font-display text-2xl font-bold text-primary-foreground shadow-glow">
          {(profile?.display_name ?? "S").slice(0, 1).toUpperCase()}
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold">{profile?.display_name}</h1>
          <p className="text-sm text-muted-foreground">
            Level {lp.level} · {stats.xp} XP · {stats.streak}-day streak
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Profile settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input placeholder="Display name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          <div className="grid grid-cols-2 gap-3">
            <SelectNative value={educationLevel} onChange={(e) => setEducationLevel(e.target.value)}>
              <option value="school">School</option>
              <option value="college">College</option>
              <option value="university">University</option>
            </SelectNative>
            <SelectNative value={language} onChange={(e) => setLanguage(e.target.value)}>
              <option value="english">English</option>
              <option value="urdu">اردو (Urdu)</option>
            </SelectNative>
          </div>
          <div className="flex justify-end">
            <Button onClick={saveProfile}>
              <Save /> Save changes
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Achievements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {BADGES.map((b) => {
              const earned = b.threshold(stats);
              return (
                <div
                  key={b.key}
                  className={cn(
                    "rounded-xl border p-3 text-center transition-all",
                    earned ? "border-primary/40 bg-primary/10" : "border-border opacity-40",
                  )}
                >
                  <p className="text-2xl">{b.emoji}</p>
                  <p className="mt-1 text-xs font-bold">{b.name}</p>
                  <p className="mt-0.5 text-[10px] text-muted-foreground">{b.description}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Account & app</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {roles?.isAdmin && (
            <Link to="/admin" className="flex items-center gap-3 rounded-lg border border-primary/40 bg-primary/10 p-3 text-sm font-medium text-primary hover:bg-primary/15">
              <ShieldCheck className="h-4 w-4" />Open Admin Panel
            </Link>
          )}
          {!anyAdmin && !roles?.isAdmin && (
            <Button
              variant="secondary"
              className="w-full"
              onClick={async () => {
                const { data, error } = await supabase.rpc("claim_first_admin");
                if (error) return toast.error(error.message);
                if (data) {
                  toast.success("You're now the admin!");
                  queryClient.invalidateQueries();
                } else {
                  toast.error("An admin already exists.");
                }
              }}
            >
              <Shield className="h-4 w-4" />Claim first admin
            </Button>
          )}
          <Link to="/notifications" className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm hover:bg-secondary"><Bell className="h-4 w-4" />Notifications</Link>
          <Link to="/support" className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm hover:bg-secondary"><MessageSquare className="h-4 w-4" />Support & feedback</Link>
          <Link to="/about" className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm hover:bg-secondary"><Info className="h-4 w-4" />About the app</Link>
          <Link to="/faq" className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm hover:bg-secondary"><HelpCircle className="h-4 w-4" />FAQ</Link>
        </CardContent>
      </Card>

      <Button variant="outline" className="w-full" onClick={handleSignOut}>
        <LogOut /> Sign out
      </Button>
    </div>
  );
}
