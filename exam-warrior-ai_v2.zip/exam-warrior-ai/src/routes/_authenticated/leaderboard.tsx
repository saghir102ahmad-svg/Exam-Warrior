import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Flame, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/leaderboard")({
  component: LeaderboardPage,
});

function LeaderboardPage() {
  const { data: rows } = useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const [{ data: profiles }, { data: userData }] = await Promise.all([
        supabase.rpc("get_leaderboard", { _limit: 50 }),
        supabase.auth.getUser(),
      ]);
      return { profiles: profiles ?? [], myId: userData.user?.id };
    },
  });

  const medals = ["🥇", "🥈", "🥉"];

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="flex items-center gap-2 font-display text-2xl font-bold">
          <Trophy className="h-6 w-6 text-gold" /> Global Leaderboard
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Top 50 Exam Warriors by XP. Study more to climb!</p>
      </div>

      <div className="space-y-2">
        {rows?.profiles.map((p, i) => {
          const isMe = p.user_id === rows.myId;
          return (
            <Card key={p.user_id} className={cn(isMe && "border-primary/50 shadow-glow")}>
              <CardContent className="flex items-center gap-3 p-3.5">
                <span className="w-8 text-center font-display text-sm font-bold text-muted-foreground">
                  {medals[i] ?? `#${i + 1}`}
                </span>
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-sm font-bold uppercase text-primary">
                  {p.display_name.slice(0, 1)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold">
                    {p.display_name} {isMe && <span className="text-xs text-primary">(you)</span>}
                  </p>
                  <p className="text-xs text-muted-foreground">Level {p.level}</p>
                </div>
                <div className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                  <Flame className="h-3.5 w-3.5 text-primary" /> {p.streak_count}
                </div>
                <div className="flex w-20 items-center justify-end gap-1 text-sm font-bold">
                  <Zap className="h-3.5 w-3.5 text-gold" /> {p.xp}
                </div>
              </CardContent>
            </Card>
          );
        })}
        {rows?.profiles.length === 0 && (
          <p className="text-sm text-muted-foreground">No warriors yet — be the first!</p>
        )}
      </div>
    </div>
  );
}
