import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { BookOpen, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useSubjects } from "@/hooks/useProfile";
import { SUBJECT_COLORS, subjectColorVar } from "@/lib/study";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/subjects")({
  component: SubjectsPage,
});

function SubjectsPage() {
  const queryClient = useQueryClient();
  const { data: subjects } = useSubjects();
  const [name, setName] = useState("");
  const [color, setColor] = useState<string>("violet");
  const [examDate, setExamDate] = useState("");

  async function addSubject(e: React.FormEvent) {
    e.preventDefault();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("subjects").insert({
      user_id: user.id,
      name,
      color,
      exam_date: examDate || null,
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    setName("");
    setExamDate("");
    queryClient.invalidateQueries({ queryKey: ["subjects"] });
    toast.success("Subject added!");
  }

  async function deleteSubject(id: string) {
    await supabase.from("subjects").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["subjects"] });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">Subjects</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage your subjects and exam dates — used across notes, quizzes and the dashboard countdown.
        </p>
      </div>

      <Card>
        <CardContent className="p-5">
          <form onSubmit={addSubject} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <Input placeholder="Subject name (e.g. Physics)" value={name} onChange={(e) => setName(e.target.value)} required />
              <Input type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} />
            </div>
            <div className="flex items-center gap-2">
              {SUBJECT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`h-7 w-7 rounded-full transition-transform ${color === c ? "scale-110 ring-2 ring-ring ring-offset-2 ring-offset-background" : ""}`}
                  style={{ backgroundColor: subjectColorVar(c) }}
                  aria-label={`Color ${c}`}
                />
              ))}
              <div className="flex-1" />
              <Button type="submit" disabled={!name.trim()}>
                <Plus /> Add subject
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {subjects?.map((s) => (
          <Card key={s.id}>
            <CardContent className="flex items-center gap-3 p-4">
              <span className="h-3.5 w-3.5 rounded-full" style={{ backgroundColor: subjectColorVar(s.color) }} />
              <BookOpen className="h-4 w-4 text-muted-foreground" />
              <span className="flex-1 font-semibold">{s.name}</span>
              {s.exam_date && (
                <span className="text-xs text-muted-foreground">
                  Exam: {format(new Date(s.exam_date), "d MMM yyyy")}
                </span>
              )}
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteSubject(s.id)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        ))}
        {subjects?.length === 0 && (
          <p className="text-sm text-muted-foreground">No subjects yet — add your first one above.</p>
        )}
      </div>
    </div>
  );
}
