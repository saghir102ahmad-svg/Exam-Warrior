import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Sparkles, Trash2, CalendarCheck } from "lucide-react";
import { format, differenceInCalendarDays } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { generateStudyPlan, awardStudyXp } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/planner")({
  component: PlannerPage,
});

function PlannerPage() {
  const queryClient = useQueryClient();
  const generate = useServerFn(generateStudyPlan);
  const awardXpFn = useServerFn(awardStudyXp);

  const [title, setTitle] = useState("");
  const [examDate, setExamDate] = useState("");
  const [subjectsText, setSubjectsText] = useState("");
  const [hoursPerDay, setHoursPerDay] = useState(3);
  const [openPlan, setOpenPlan] = useState<string | null>(null);

  const { data: plans } = useQuery({
    queryKey: ["plans"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("study_plans")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: tasks } = useQuery({
    queryKey: ["plan-tasks", openPlan],
    enabled: !!openPlan,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plan_tasks")
        .select("*")
        .eq("plan_id", openPlan!)
        .order("task_date");
      if (error) throw error;
      return data;
    },
  });

  const genMutation = useMutation({
    mutationFn: () =>
      generate({
        data: {
          title: title || "My study plan",
          examDate,
          subjects: subjectsText.split(",").map((s) => s.trim()).filter(Boolean),
          hoursPerDay,
        },
      }),
    onSuccess: (plan) => {
      toast.success("Study plan created! +25 XP ⚡");
      setTitle("");
      setSubjectsText("");
      setOpenPlan(plan.id);
      queryClient.invalidateQueries({ queryKey: ["plans"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to create plan"),
  });

  async function toggleTask(id: string, completed: boolean) {
    await supabase.from("plan_tasks").update({ completed: !completed }).eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["plan-tasks", openPlan] });
    queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
    if (!completed) {
      awardXpFn({ data: { reason: "task_completed" } }).then(() =>
        queryClient.invalidateQueries({ queryKey: ["profile"] }),
      );
      toast.success("Task done! +5 XP ⚡");
    }
  }

  async function deletePlan(id: string) {
    await supabase.from("study_plans").delete().eq("id", id);
    if (openPlan === id) setOpenPlan(null);
    queryClient.invalidateQueries({ queryKey: ["plans"] });
  }

  const tasksByDate = new Map<string, NonNullable<typeof tasks>>();
  for (const t of tasks ?? []) {
    const list = tasksByDate.get(t.task_date) ?? [];
    list.push(t);
    tasksByDate.set(t.task_date, list);
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">Smart Revision Planner</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Enter your exam date and subjects — AI builds your daily timetable.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Input placeholder="Plan name (e.g. Finals Prep)" value={title} onChange={(e) => setTitle(e.target.value)} />
            <Input type="date" value={examDate} min={new Date(Date.now() + 86400000).toISOString().slice(0, 10)} onChange={(e) => setExamDate(e.target.value)} />
          </div>
          <Input
            placeholder="Subjects, comma separated (e.g. Physics, Chemistry, Math)"
            value={subjectsText}
            onChange={(e) => setSubjectsText(e.target.value)}
          />
          <div className="flex items-center gap-3">
            <label className="text-sm text-muted-foreground">Study hours/day:</label>
            <Input
              type="number"
              min={1}
              max={12}
              className="w-24"
              value={hoursPerDay}
              onChange={(e) => setHoursPerDay(Number(e.target.value))}
            />
            <div className="flex-1" />
            <Button
              variant="hero"
              onClick={() => genMutation.mutate()}
              disabled={genMutation.isPending || !examDate || !subjectsText.trim()}
            >
              {genMutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {genMutation.isPending ? "Building plan..." : "Generate Plan"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold">Your plans ({plans?.length ?? 0})</h2>
        {plans?.length === 0 && (
          <p className="text-sm text-muted-foreground">No plans yet — create one above!</p>
        )}
        {plans?.map((plan) => (
          <Card key={plan.id}>
            <CardHeader className="cursor-pointer" onClick={() => setOpenPlan(openPlan === plan.id ? null : plan.id)}>
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <CalendarCheck className="h-4 w-4 text-primary" /> {plan.title}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                    {Math.max(0, differenceInCalendarDays(new Date(plan.exam_date), new Date()))} days left
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation();
                      deletePlan(plan.id);
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            {openPlan === plan.id && (
              <CardContent className="space-y-4">
                {[...tasksByDate.entries()].map(([date, dayTasks]) => (
                  <div key={date}>
                    <p className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                      {format(new Date(date), "EEEE, d MMM")}
                    </p>
                    <div className="space-y-1.5">
                      {dayTasks?.map((t) => (
                        <label
                          key={t.id}
                          className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border p-2.5 text-sm transition-colors hover:bg-secondary"
                        >
                          <input
                            type="checkbox"
                            checked={t.completed}
                            onChange={() => toggleTask(t.id, t.completed)}
                            className="mt-0.5 accent-[var(--primary)]"
                          />
                          <span className={t.completed ? "text-muted-foreground line-through" : ""}>
                            <span className="font-semibold text-primary">{t.subject}:</span> {t.task}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
