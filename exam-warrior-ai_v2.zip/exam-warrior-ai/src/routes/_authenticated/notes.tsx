import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { Loader2, FileText, Trash2, ChevronDown, ImagePlus, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { generateNotes } from "@/lib/ai.functions";
import { useSubjects } from "@/hooks/useProfile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/notes")({
  component: NotesPage,
});

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function NotesPage() {
  const queryClient = useQueryClient();
  const generate = useServerFn(generateNotes);
  const { data: subjects } = useSubjects();

  const [title, setTitle] = useState("");
  const [sourceText, setSourceText] = useState("");
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [language, setLanguage] = useState<"english" | "urdu">("english");
  const [subjectId, setSubjectId] = useState("");
  const [openNote, setOpenNote] = useState<string | null>(null);

  const { data: notes } = useQuery({
    queryKey: ["notes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notes")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const mutation = useMutation({
    mutationFn: () =>
      generate({
        data: {
          title: title || "Untitled notes",
          sourceText: sourceText || undefined,
          imageDataUrl: imageDataUrl ?? undefined,
          language,
          subjectId: subjectId || null,
        },
      }),
    onSuccess: (note) => {
      toast.success("Notes generated! +20 XP ⚡");
      setTitle("");
      setSourceText("");
      setImageDataUrl(null);
      setOpenNote(note.id);
      queryClient.invalidateQueries({ queryKey: ["notes"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to generate notes"),
  });

  async function handleImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      toast.error("Image must be under 4MB");
      return;
    }
    setImageDataUrl(await fileToDataUrl(file));
  }

  async function deleteNote(id: string) {
    await supabase.from("notes").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["notes"] });
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">AI Notes Generator</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Paste a chapter or upload a photo — get short, exam-ready notes instantly.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Input placeholder="Title (e.g. Chapter 4: Chemical Bonds)" value={title} onChange={(e) => setTitle(e.target.value)} />
            <div className="grid grid-cols-2 gap-3">
              <SelectNative value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
                <option value="">No subject</option>
                {subjects?.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </SelectNative>
              <SelectNative value={language} onChange={(e) => setLanguage(e.target.value as "english" | "urdu")}>
                <option value="english">English</option>
                <option value="urdu">اردو (Urdu)</option>
              </SelectNative>
            </div>
          </div>
          <Textarea
            placeholder="Paste your chapter text, textbook content, or class notes here..."
            rows={6}
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
          />
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
              <ImagePlus className="h-4 w-4" />
              {imageDataUrl ? "Image attached ✓" : "Attach photo of page"}
              <input type="file" accept="image/*" className="hidden" onChange={handleImage} />
            </label>
            {imageDataUrl && (
              <button className="text-xs text-destructive underline" onClick={() => setImageDataUrl(null)}>
                Remove image
              </button>
            )}
            <div className="flex-1" />
            <Button
              variant="hero"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending || (!sourceText.trim() && !imageDataUrl)}
            >
              {mutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {mutation.isPending ? "Generating..." : "Generate Notes"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold">Your notes ({notes?.length ?? 0})</h2>
        {notes?.length === 0 && (
          <p className="text-sm text-muted-foreground">No notes yet — generate your first set above!</p>
        )}
        {notes?.map((note) => (
          <Card key={note.id}>
            <CardHeader
              className="cursor-pointer"
              onClick={() => setOpenNote(openNote === note.id ? null : note.id)}
            >
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                  <FileText className="h-4 w-4 text-primary" /> {note.title}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(note.created_at), "d MMM")}
                  </span>
                  <ChevronDown
                    className={`h-4 w-4 text-muted-foreground transition-transform ${openNote === note.id ? "rotate-180" : ""}`}
                  />
                </div>
              </div>
            </CardHeader>
            {openNote === note.id && (
              <CardContent>
                <div className={`prose-notes text-sm ${note.language === "urdu" ? "text-right" : ""}`} dir={note.language === "urdu" ? "rtl" : "ltr"}>
                  <ReactMarkdown>{note.content}</ReactMarkdown>
                </div>
                <div className="mt-4 flex justify-end">
                  <Button variant="ghost" size="sm" onClick={() => deleteNote(note.id)}>
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
