import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Target, Sparkles, CheckCircle2, XCircle, RotateCcw, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { generateMcqs, submitQuizAttempt } from "@/lib/ai.functions";
import { useSubjects } from "@/hooks/useProfile";
import type { McqQuestion } from "@/lib/study";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/quiz")({
  component: QuizPage,
});

type QuizRow = {
  id: string;
  title: string;
  difficulty: string;
  questions: unknown;
  created_at: string;
};

function QuizPage() {
  const queryClient = useQueryClient();
  const generate = useServerFn(generateMcqs);
  const submit = useServerFn(submitQuizAttempt);
  const { data: subjects } = useSubjects();

  const [title, setTitle] = useState("");
  const [sourceText, setSourceText] = useState("");
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [count, setCount] = useState(5);
  const [subjectId, setSubjectId] = useState("");

  const [activeQuiz, setActiveQuiz] = useState<QuizRow | null>(null);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [result, setResult] = useState<{ score: number; total: number } | null>(null);

  const { data: quizzes } = useQuery({
    queryKey: ["quizzes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quizzes")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as QuizRow[];
    },
  });

  const genMutation = useMutation({
    mutationFn: () =>
      generate({
        data: {
          title: title || "Practice quiz",
          sourceText,
          difficulty,
          count,
          subjectId: subjectId || null,
        },
      }),
    onSuccess: (quiz) => {
      toast.success("Quiz ready! Good luck 🎯");
      setTitle("");
      setSourceText("");
      queryClient.invalidateQueries({ queryKey: ["quizzes"] });
      startQuiz(quiz as QuizRow);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to generate quiz"),
  });

  const submitMutation = useMutation({
    mutationFn: (payload: { quizId: string; answers: number[] }) => submit({ data: payload }),
    onSuccess: (res) => {
      setResult(res);
      toast.success(`Scored ${res.score}/${res.total} — +30 XP ⚡`);
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to submit"),
  });

  function startQuiz(quiz: QuizRow) {
    setActiveQuiz(quiz);
    setAnswers({});
    setResult(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function deleteQuiz(id: string) {
    await supabase.from("quizzes").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["quizzes"] });
  }

  const questions = (activeQuiz?.questions ?? []) as McqQuestion[];
  const allAnswered = questions.length > 0 && questions.every((_, i) => answers[i] !== undefined);

  // ---------- Taking a quiz ----------
  if (activeQuiz) {
    return (
      <div className="mx-auto max-w-2xl space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-xl font-bold">{activeQuiz.title}</h1>
            <p className="text-xs capitalize text-muted-foreground">
              {activeQuiz.difficulty} · {questions.length} questions
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setActiveQuiz(null)}>
            ← Back
          </Button>
        </div>

        {result && (
          <Card className="border-primary/50 shadow-glow">
            <CardContent className="flex items-center justify-between p-5">
              <div>
                <p className="font-display text-2xl font-bold">
                  {result.score} / {result.total}
                </p>
                <p className="text-sm text-muted-foreground">
                  {result.score / result.total >= 0.8
                    ? "Outstanding! 🏆"
                    : result.score / result.total >= 0.5
                      ? "Good work — review the explanations below."
                      : "Keep practicing — check the explanations below."}
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={() => startQuiz(activeQuiz)}>
                <RotateCcw className="h-3.5 w-3.5" /> Retry
              </Button>
            </CardContent>
          </Card>
        )}

        {questions.map((q, qi) => (
          <Card key={qi}>
            <CardContent className="p-5">
              <p className="mb-3 font-semibold">
                {qi + 1}. {q.question}
              </p>
              <div className="space-y-2">
                {q.options.map((opt, oi) => {
                  const selected = answers[qi] === oi;
                  const showResult = result !== null;
                  const isCorrect = oi === q.answerIndex;
                  return (
                    <button
                      key={oi}
                      disabled={showResult}
                      onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                      className={cn(
                        "flex w-full items-center gap-2 rounded-lg border px-3 py-2.5 text-left text-sm transition-colors",
                        showResult && isCorrect
                          ? "border-success bg-success/10 text-success"
                          : showResult && selected && !isCorrect
                            ? "border-destructive bg-destructive/10 text-destructive"
                            : selected
                              ? "border-primary bg-primary/10"
                              : "border-border hover:bg-secondary",
                      )}
                    >
                      {showResult && isCorrect && <CheckCircle2 className="h-4 w-4 shrink-0" />}
                      {showResult && selected && !isCorrect && <XCircle className="h-4 w-4 shrink-0" />}
                      {opt}
                    </button>
                  );
                })}
              </div>
              {result && (
                <p className="mt-3 rounded-lg bg-secondary p-3 text-xs text-muted-foreground">
                  💡 {q.explanation}
                </p>
              )}
            </CardContent>
          </Card>
        ))}

        {!result && (
          <Button
            variant="hero"
            size="lg"
            className="w-full"
            disabled={!allAnswered || submitMutation.isPending}
            onClick={() =>
              submitMutation.mutate({
                quizId: activeQuiz.id,
                answers: questions.map((_, i) => answers[i] ?? -1),
              })
            }
          >
            {submitMutation.isPending && <Loader2 className="animate-spin" />}
            Submit Answers
          </Button>
        )}
      </div>
    );
  }

  // ---------- Generator + list ----------
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">AI MCQ Generator</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Generate unlimited practice MCQs with instant checking and explanations.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Input placeholder="Quiz title (e.g. Newton's Laws)" value={title} onChange={(e) => setTitle(e.target.value)} />
            <div className="grid grid-cols-3 gap-3">
              <SelectNative value={difficulty} onChange={(e) => setDifficulty(e.target.value as typeof difficulty)}>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </SelectNative>
              <SelectNative value={count} onChange={(e) => setCount(Number(e.target.value))}>
                {[5, 8, 10, 15].map((n) => (
                  <option key={n} value={n}>
                    {n} Qs
                  </option>
                ))}
              </SelectNative>
              <SelectNative value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
                <option value="">Subject</option>
                {subjects?.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </SelectNative>
            </div>
          </div>
          <Textarea
            placeholder="Paste the chapter, notes or topic content to generate questions from..."
            rows={5}
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
          />
          <div className="flex justify-end">
            <Button
              variant="hero"
              onClick={() => genMutation.mutate()}
              disabled={genMutation.isPending || sourceText.trim().length < 20}
            >
              {genMutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {genMutation.isPending ? "Generating..." : "Generate Quiz"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold">Your quizzes ({quizzes?.length ?? 0})</h2>
        {quizzes?.length === 0 && (
          <p className="text-sm text-muted-foreground">No quizzes yet — generate one above!</p>
        )}
        {quizzes?.map((quiz) => (
          <Card key={quiz.id}>
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="h-4 w-4 text-primary" /> {quiz.title}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs capitalize text-muted-foreground">
                    {quiz.difficulty}
                  </span>
                  <Button size="sm" onClick={() => startQuiz(quiz)}>
                    Take quiz
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteQuiz(quiz.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  );
}
