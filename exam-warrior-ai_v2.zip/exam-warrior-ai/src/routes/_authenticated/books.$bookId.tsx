import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ChevronLeft, ChevronRight, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { askBook } from "@/lib/books.functions";
import type { BookAnswer, Citation } from "@/lib/book-types";

export const Route = createFileRoute("/_authenticated/books/$bookId")({
  head: () => ({
    meta: [
      { title: "Book Reader — Exam Warrior AI" },
      { name: "description", content: "Read your book and get answers with clickable page citations." },
    ],
  }),
  component: BookViewer,
});

type QA = { q: string; a: BookAnswer };

function BookViewer() {
  const { bookId } = Route.useParams();
  const [pdf, setPdf] = useState<any>(null);
  const [page, setPage] = useState(1);
  const [highlight, setHighlight] = useState<string | null>(null);
  const [question, setQuestion] = useState("");
  const [asking, setAsking] = useState(false);
  const [history, setHistory] = useState<QA[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  const { data: book } = useQuery({
    queryKey: ["book", bookId],
    queryFn: async () => {
      const { data, error } = await supabase.from("books").select("*").eq("id", bookId).single();
      if (error) throw error;
      return data;
    },
  });

  // Load PDF
  useEffect(() => {
    if (!book) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase.storage.from("books").download(book.file_path);
      if (error || !data) return toast.error("Could not load the PDF");
      const { loadPdfJs } = await import("@/lib/pdf-parse");
      const pdfjs = await loadPdfJs();
      const doc = await pdfjs.getDocument({ data: await data.arrayBuffer() }).promise;
      if (!cancelled) setPdf(doc);
    })();
    return () => {
      cancelled = true;
    };
  }, [book]);

  // Render page + text layer with highlight
  useEffect(() => {
    if (!pdf || !canvasRef.current || !textRef.current) return;
    let task: any;
    (async () => {
      const p = await pdf.getPage(page);
      const width = Math.min(canvasRef.current!.parentElement!.clientWidth, 900);
      const base = p.getViewport({ scale: 1 });
      const viewport = p.getViewport({ scale: width / base.width });
      const canvas = canvasRef.current!;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      task = p.render({ canvas, canvasContext: canvas.getContext("2d")!, viewport });
      await task.promise.catch(() => {});

      const layer = textRef.current!;
      layer.innerHTML = "";
      layer.style.width = `${viewport.width}px`;
      layer.style.height = `${viewport.height}px`;
      if (!highlight) return;
      const words = new Set(
        highlight.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 3),
      );
      const content = await p.getTextContent();
      let first: HTMLElement | null = null;
      for (const item of content.items as any[]) {
        if (!item.str?.trim()) continue;
        const tokens = item.str.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w: string) => w.length > 3);
        const hits = tokens.filter((t: string) => words.has(t)).length;
        if (!tokens.length || hits / tokens.length < 0.5) continue;
        const [x, y] = viewport.convertToViewportPoint(item.transform[4], item.transform[5]);
        const h = Math.hypot(item.transform[2], item.transform[3]) * viewport.scale;
        const el = document.createElement("div");
        el.className = "absolute rounded-sm bg-primary/30";
        el.style.left = `${x}px`;
        el.style.top = `${y - h}px`;
        el.style.width = `${item.width * viewport.scale}px`;
        el.style.height = `${h * 1.2}px`;
        layer.appendChild(el);
        first ??= el;
      }
      first?.scrollIntoView({ behavior: "smooth", block: "center" });
    })();
    return () => task?.cancel?.();
  }, [pdf, page, highlight]);

  function openCitation(c: Citation) {
    setPage(c.pdfPage);
    setHighlight(c.quote);
  }

  async function ask(e: React.FormEvent) {
    e.preventDefault();
    const q = question.trim();
    if (q.length < 3) return;
    setAsking(true);
    try {
      const a = await askBook({ data: { bookId, question: q } });
      setHistory((h) => [...h, { q, a }]);
      setQuestion("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to answer");
    } finally {
      setAsking(false);
    }
  }

  const total = pdf?.numPages ?? book?.page_count ?? 1;

  return (
    <div className="mx-auto grid max-w-7xl gap-4 lg:grid-cols-[1fr_380px]">
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <Link to="/books" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> {book?.title ?? "Books"}
          </Link>
          <div className="flex items-center gap-2">
            <Button size="icon" variant="outline" disabled={page <= 1} onClick={() => { setHighlight(null); setPage(page - 1); }} aria-label="Previous page">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Input
              type="number"
              className="w-16 text-center"
              value={page}
              min={1}
              max={total}
              onChange={(e) => {
                const n = Number(e.target.value);
                if (n >= 1 && n <= total) { setHighlight(null); setPage(n); }
              }}
            />
            <span className="text-xs text-muted-foreground">/ {total}</span>
            <Button size="icon" variant="outline" disabled={page >= total} onClick={() => { setHighlight(null); setPage(page + 1); }} aria-label="Next page">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="relative overflow-auto rounded-lg border border-border bg-card">
          {!pdf && (
            <div className="flex h-96 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          )}
          <div className="relative mx-auto w-fit">
            <canvas ref={canvasRef} className="block" />
            <div ref={textRef} className="pointer-events-none absolute left-0 top-0" />
          </div>
        </div>
      </div>

      <Card className="flex h-[calc(100vh-8rem)] flex-col lg:sticky lg:top-20">
        <CardContent className="flex flex-1 flex-col gap-3 overflow-hidden p-4">
          <h2 className="font-display font-semibold">Ask this book</h2>
          <div className="flex-1 space-y-4 overflow-y-auto pr-1">
            {history.length === 0 && (
              <p className="text-sm text-muted-foreground">Try: "What is the main idea of chapter 1?"</p>
            )}
            {history.map((h, i) => (
              <div key={i} className="space-y-2">
                <p className="rounded-lg bg-secondary p-2 text-sm font-medium">{h.q}</p>
                <div className="space-y-2 rounded-lg border border-border p-3 text-sm">
                  <p className="whitespace-pre-line">{h.a.answer}</p>
                  {h.a.found && h.a.citations.length > 0 && (
                    <div className="space-y-2 border-t border-border pt-2">
                      <p className="text-xs font-semibold uppercase text-muted-foreground">
                        📚 {h.a.citations.length > 1 ? "Sources" : "Source"} · {h.a.confidence} confidence
                      </p>
                      {h.a.citations.map((c, j) => (
                        <div key={j} className="space-y-0.5 text-xs">
                          <button onClick={() => openCitation(c)} className="font-semibold text-primary hover:underline">
                            📖 PDF Page {c.pdfPage}
                            {c.bookPage ? ` (Book Page ${c.bookPage})` : ""} → Open page
                          </button>
                          {c.chapter && <p>📍 {c.chapter}{c.section ? ` — ${c.section}` : ""}</p>}
                          {!c.chapter && c.heading && <p>📍 {c.heading}</p>}
                          {c.lineStart && c.lineEnd && <p>📌 Lines {c.lineStart}–{c.lineEnd}</p>}
                          {c.quote && <p className="italic text-muted-foreground">"{c.quote}"</p>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          <form onSubmit={ask} className="flex gap-2">
            <Input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Ask a question…" disabled={asking} />
            <Button type="submit" size="icon" disabled={asking} aria-label="Ask">
              {asking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
