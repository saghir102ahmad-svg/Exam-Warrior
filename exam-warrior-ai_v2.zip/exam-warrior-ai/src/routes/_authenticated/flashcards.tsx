import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Layers, Sparkles, Star, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { generateFlashcards, awardStudyXp } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/flashcards")({
  component: FlashcardsPage,
});

type CardRow = {
  id: string;
  front: string;
  back: string;
  is_favorite: boolean;
  due_at: string;
  interval_days: number;
  ease: number;
  review_count: number;
};

function FlashcardsPage() {
  const queryClient = useQueryClient();
  const generate = useServerFn(generateFlashcards);
  const awardXpFn = useServerFn(awardStudyXp);

  const [title, setTitle] = useState("");
  const [sourceText, setSourceText] = useState("");
  const [studyDeck, setStudyDeck] = useState<string | null>(null);
  const [flipped, setFlipped] = useState(false);
  const [cardIndex, setCardIndex] = useState(0);

  const { data: decks } = useQuery({
    queryKey: ["decks"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("flashcard_decks")
        .select("*, flashcards(count)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: cards } = useQuery({
    queryKey: ["cards", studyDeck],
    enabled: !!studyDeck,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("flashcards")
        .select("*")
        .eq("deck_id", studyDeck!)
        .order("due_at");
      if (error) throw error;
      return data as CardRow[];
    },
  });

  const genMutation = useMutation({
    mutationFn: () =>
      generate({ data: { title: title || "Flashcards", sourceText, count: 12, subjectId: null } }),
    onSuccess: () => {
      toast.success("Flashcards created! +20 XP ⚡");
      setTitle("");
      setSourceText("");
      queryClient.invalidateQueries({ queryKey: ["decks"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to generate flashcards"),
  });

  async function review(card: CardRow, quality: "again" | "good" | "easy") {
    // Lightweight SM-2 style scheduling
    let interval = card.interval_days;
    let ease = card.ease;
    if (quality === "again") {
      interval = 0;
      ease = Math.max(1.3, ease - 0.2);
    } else if (quality === "good") {
      interval = interval === 0 ? 1 : interval * ease;
    } else {
      interval = interval === 0 ? 2 : interval * ease * 1.3;
      ease = ease + 0.1;
    }
    const due = new Date(Date.now() + Math.max(0.007, interval) * 86400000).toISOString();
    await supabase
      .from("flashcards")
      .update({ interval_days: interval, ease, due_at: due, review_count: card.review_count + 1 })
      .eq("id", card.id);
    awardXpFn({ data: { reason: "flashcard_reviewed" } }).then(() =>
      queryClient.invalidateQueries({ queryKey: ["profile"] }),
    );
    setFlipped(false);
    if (cardIndex + 1 >= (cards?.length ?? 0)) {
      toast.success("Deck complete! Great work 🎉");
      setStudyDeck(null);
      setCardIndex(0);
    } else {
      setCardIndex((i) => i + 1);
    }
  }

  async function toggleFavorite(card: CardRow) {
    await supabase.from("flashcards").update({ is_favorite: !card.is_favorite }).eq("id", card.id);
    queryClient.invalidateQueries({ queryKey: ["cards", studyDeck] });
  }

  async function deleteDeck(id: string) {
    await supabase.from("flashcard_decks").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["decks"] });
  }

  // Study mode
  if (studyDeck && cards) {
    const card = cards[cardIndex];
    if (!card) {
      setStudyDeck(null);
      return null;
    }
    return (
      <div className="mx-auto max-w-xl space-y-5">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Card {cardIndex + 1} of {cards.length}
          </p>
          <Button variant="ghost" size="sm" onClick={() => { setStudyDeck(null); setCardIndex(0); setFlipped(false); }}>
            ← Back to decks
          </Button>
        </div>
        <button
          className="flex min-h-64 w-full cursor-pointer items-center justify-center rounded-2xl border border-border bg-card p-8 text-center shadow-card transition-all hover:border-primary/40"
          onClick={() => setFlipped((f) => !f)}
        >
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {flipped ? "Answer" : "Question — tap to flip"}
            </p>
            <p className="font-display text-lg font-semibold">{flipped ? card.back : card.front}</p>
          </div>
        </button>
        <div className="flex items-center justify-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => toggleFavorite(card)}>
            <Star className={card.is_favorite ? "fill-gold text-gold" : "text-muted-foreground"} />
          </Button>
        </div>
        {flipped && (
          <div className="grid grid-cols-3 gap-3">
            <Button variant="destructive" onClick={() => review(card, "again")}>Again</Button>
            <Button variant="secondary" onClick={() => review(card, "good")}>Good</Button>
            <Button variant="hero" onClick={() => review(card, "easy")}>Easy</Button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">AI Flashcards</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Auto-generate flashcards and master them with spaced repetition.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-5">
          <Input placeholder="Deck title (e.g. Biology: Cell Structure)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Textarea
            placeholder="Paste study material to turn into flashcards..."
            rows={4}
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
          />
          <div className="flex justify-end">
            <Button
              variant="hero"
              onClick={() => genMutation.mutate()}
              disabled={genMutation.isPending || sourceText.trim().length < 20}
            >
              {genMutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {genMutation.isPending ? "Generating..." : "Generate Flashcards"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold">Your decks ({decks?.length ?? 0})</h2>
        {decks?.length === 0 && (
          <p className="text-sm text-muted-foreground">No decks yet — create one above!</p>
        )}
        {decks?.map((deck) => (
          <Card key={deck.id}>
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Layers className="h-4 w-4 text-primary" /> {deck.title}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    {(deck.flashcards as unknown as { count: number }[])?.[0]?.count ?? 0} cards
                  </span>
                  <Button size="sm" onClick={() => { setStudyDeck(deck.id); setCardIndex(0); setFlipped(false); }}>
                    Study
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteDeck(deck.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  );
}
