import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/notifications")({
  component: NotificationsPage,
});

function NotificationsPage() {
  const { data } = useQuery({
    queryKey: ["broadcasts"],
    queryFn: async () => {
      const { data } = await supabase
        .from("broadcast_notifications")
        .select("*")
        .order("published_at", { ascending: false })
        .limit(100);
      return data ?? [];
    },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2"><Bell className="h-7 w-7 text-primary" />Notifications</h1>
        <p className="text-sm text-muted-foreground">Announcements from the Exam Warrior AI team.</p>
      </div>

      <div className="space-y-3">
        {(data ?? []).map((n: any) => (
          <Card key={n.id}>
            <CardContent className="p-4 space-y-1">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="font-semibold">{n.title}</h2>
                <span className="text-xs text-muted-foreground">{new Date(n.published_at).toLocaleString()}</span>
              </div>
              <p className="text-sm text-muted-foreground whitespace-pre-line">{n.message}</p>
              {n.target !== "all" && <span className="inline-block rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase">{n.target}</span>}
            </CardContent>
          </Card>
        ))}
        {data?.length === 0 && <p className="text-sm text-muted-foreground">No notifications yet.</p>}
      </div>
    </div>
  );
}
