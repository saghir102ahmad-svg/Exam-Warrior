import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Flame,
  Zap,
  FileText,
  Target,
  Layers,
  CalendarCheck,
  Camera,
  MessageCircle,
  Trophy,
  AlertTriangle,
  Quote,
  Timer,
  ShieldCheck,
  Megaphone,
  Settings,
  MessageCircle as MessageCircleIcon,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  Tooltip,
} from "recharts";
import { format, differenceInCalendarDays } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/hooks/useProfile";
import { useRoles } from "@/hooks/useRoles";
import { levelProgress } from "@/lib/xp";
import { todaysQuote } from "@/lib/study";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

const QUICK_ACTIONS = [
  { to: "/notes", label: "AI Notes", icon: FileText },
  { to: "/quiz", label: "MCQ Quiz", icon: Target },
  { to: "/flashcards", label: "Flashcards", icon: Layers },
  { to: "/planner", label: "Planner", icon: CalendarCheck },
  { to: "/doubts", label: "DoubtSnap", icon: Camera },
  { to: "/assistant", label: "Ask AI", icon: MessageCircle },
] as const;

function Dashboard() {
  const { data: profile } = useProfile();
  const { data: roles } = useRoles();

  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const [notes, attempts, dueCards, xpEvents, subjects, tasks] = await Promise.all([
        supabase.from("notes").select("id", { count: "exact", head: true }),
        supabase
          .from("quiz_attempts")
          .select("score,total,created_at,quizzes(title)")
          .order("created_at", { ascending: false })
          .limit(50),
        supabase
          .from("flashcards")
          .select("id", { count: "exact", head: true })
          .lte("due_at", new Date().toISOString()),
        supabase
          .from("xp_events")
          .select("amount,created_at")
          .gte("created_at", new Date(Date.now() - 7 * 86400000).toISOString()),
        supabase.from("subjects").select("name,exam_date").not("exam_date", "is", null),
        supabase
          .from("plan_tasks")
          .select("id,task,subject,completed")
          .eq("task_date", new Date().toISOString().slice(0, 10))
          .limit(5),
      ]);
      return {
        notesCount: notes.count ?? 0,
        attempts: attempts.data ?? [],
        dueCards: dueCards.count ?? 0,
        xpEvents: xpEvents.data ?? [],
        subjects: subjects.data ?? [],
        todayTasks: tasks.data ?? [],
      };
    },
  });

  const xp = profile?.xp ?? 0;
  const lp = levelProgress(xp);

  // XP per day chart
  const chartData = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const key = d.toISOString().slice(0, 10);
    const total = (stats?.xpEvents ?? [])
      .filter((e) => e.created_at.slice(0, 10) === key)
      .reduce((s, e) => s + e.amount, 0);
    return { day: format(d, "EEE"), xp: total };
  });

  // Weak topics: quiz titles with accuracy < 70%
  const byQuiz = new Map<string, { score: number; total: number }>();
  for (const a of stats?.attempts ?? []) {
    const title = (a.quizzes as { title: string } | null)?.title ?? "Quiz";
    const cur = byQuiz.get(title) ?? { score: 0, total: 0 };
    byQuiz.set(title, { score: cur.score + a.score, total: cur.total + a.total });
  }
  const weakTopics = [...byQuiz.entries()]
    .map(([title, s]) => ({ title, pct: Math.round((s.score / Math.max(1, s.total)) * 100) }))
    .filter((t) => t.pct < 70)
    .sort((a, b) => a.pct - b.pct)
    .slice(0, 3);

  // Nearest exam
  const upcomingExams = (stats?.subjects ?? [])
    .filter((s) => s.exam_date && s.exam_date >= new Date().toISOString().slice(0, 10))
    .sort((a, b) => (a.exam_date! < b.exam_date! ? -1 : 1));
  const nextExam = upcomingExams[0];

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold lg:text-3xl">
          Welcome back, <span className="text-gradient">{profile?.display_name ?? "Warrior"}</span> ⚔️
        </h1>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
          <Quote className="h-3.5 w-3.5 shrink-0" /> {todaysQuote()}
        </p>
      </div>

      {roles?.isModerator && (
        <Card className="border-gold/40 bg-gradient-to-br from-gold/10 to-primary/5">
          <CardContent className="p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold/20">
                  <ShieldCheck className="h-6 w-6 text-gold" />
                </div>
                <div>
                  <p className="font-display font-bold">{roles.isAdmin ? "Admin panel" : "Moderator panel"}</p>
                  <p className="text-xs text-muted-foreground">Manage users, content, announcements and app updates.</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link to="/admin" className="rounded-lg bg-gold px-3 py-2 text-xs font-semibold text-background hover:opacity-90">Open panel</Link>
                <Link to="/admin/broadcasts" className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"><Megaphone className="h-3.5 w-3.5" />Announce</Link>
                <Link to="/admin/users" className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"><ShieldCheck className="h-3.5 w-3.5" />Users</Link>
                <Link to="/admin/chats" className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"><MessageCircleIcon className="h-3.5 w-3.5" />Chats</Link>
                {roles.isAdmin && (
                  <Link to="/admin/config" className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"><Settings className="h-3.5 w-3.5" />Force update</Link>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}



      {/* Level + streak row */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="sm:col-span-2">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl gradient-primary font-display text-lg font-bold text-primary-foreground shadow-glow">
                  {lp.level}
                </div>
                <div>
                  <p className="font-display font-bold">Level {lp.level}</p>
                  <p className="text-xs text-muted-foreground">
                    {lp.current} / {lp.needed} XP to level {lp.level + 1}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-sm font-semibold">
                <Zap className="h-4 w-4 text-gold" /> {xp} XP
              </div>
            </div>
            <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full gradient-primary transition-all"
                style={{ width: `${lp.pct}%` }}
              />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex h-full items-center gap-4 p-5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15">
              <Flame className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-display text-2xl font-bold">{profile?.streak_count ?? 0}</p>
              <p className="text-xs text-muted-foreground">day streak — keep it alive!</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {QUICK_ACTIONS.map((a) => (
          <Link
            key={a.to}
            to={a.to}
            className="group flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/40 hover:shadow-glow"
          >
            <a.icon className="h-5 w-5 text-primary transition-transform group-hover:scale-110" />
            <span className="text-center text-xs font-medium">{a.label}</span>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* XP chart */}
        <Card>
          <CardHeader>
            <CardTitle>XP this week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip
                    cursor={{ fill: "var(--secondary)" }}
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "0.5rem",
                      color: "var(--foreground)",
                    }}
                  />
                  <Bar dataKey="xp" fill="var(--primary)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Exam countdown + today's tasks */}
        <div className="space-y-4">
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/15">
                <Timer className="h-6 w-6 text-accent" />
              </div>
              {nextExam ? (
                <div>
                  <p className="font-display text-2xl font-bold">
                    {differenceInCalendarDays(new Date(nextExam.exam_date!), new Date())} days
                  </p>
                  <p className="text-xs text-muted-foreground">
                    until your {nextExam.name} exam ({format(new Date(nextExam.exam_date!), "d MMM")})
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-semibold">No exam scheduled</p>
                  <p className="text-xs text-muted-foreground">
                    Add exam dates in <Link to="/subjects" className="text-primary underline">Subjects</Link>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Today's plan</CardTitle>
            </CardHeader>
            <CardContent>
              {stats?.todayTasks.length ? (
                <ul className="space-y-2">
                  {stats.todayTasks.map((t) => (
                    <li key={t.id} className="flex items-center gap-2 text-sm">
                      <span
                        className={`h-2 w-2 shrink-0 rounded-full ${t.completed ? "bg-success" : "bg-primary"}`}
                      />
                      <span className={t.completed ? "text-muted-foreground line-through" : ""}>
                        <span className="font-semibold">{t.subject}:</span> {t.task}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No tasks for today.{" "}
                  <Link to="/planner" className="text-primary underline">
                    Create a study plan
                  </Link>
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Stats + weak topics */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Your study stats</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-3 gap-3 text-center">
            <div className="rounded-lg bg-secondary p-3">
              <p className="font-display text-xl font-bold text-primary">{stats?.notesCount ?? 0}</p>
              <p className="text-xs text-muted-foreground">Notes</p>
            </div>
            <div className="rounded-lg bg-secondary p-3">
              <p className="font-display text-xl font-bold text-accent">{stats?.attempts.length ?? 0}</p>
              <p className="text-xs text-muted-foreground">Quizzes taken</p>
            </div>
            <div className="rounded-lg bg-secondary p-3">
              <p className="font-display text-xl font-bold text-gold">{stats?.dueCards ?? 0}</p>
              <p className="text-xs text-muted-foreground">Cards due</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" /> Weak topics
            </CardTitle>
          </CardHeader>
          <CardContent>
            {weakTopics.length ? (
              <ul className="space-y-3">
                {weakTopics.map((t) => (
                  <li key={t.title}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{t.title}</span>
                      <span className="text-destructive">{t.pct}%</span>
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full rounded-full bg-destructive" style={{ width: `${t.pct}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">
                No weak topics detected yet — take some{" "}
                <Link to="/quiz" className="text-primary underline">
                  quizzes
                </Link>{" "}
                to analyze your performance.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-center">
        <Link
          to="/leaderboard"
          className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <Trophy className="h-4 w-4 text-gold" /> See where you rank on the leaderboard
        </Link>
      </div>
    </div>
  );
}
