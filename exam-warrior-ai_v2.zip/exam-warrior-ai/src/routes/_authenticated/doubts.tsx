import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { Loader2, Camera, Sparkles, ChevronDown, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { solveDoubt } from "@/lib/ai.functions";
import { DOUBT_SUBJECTS } from "@/lib/study";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/doubts")({
  component: DoubtsPage,
});

function DoubtsPage() {
  const queryClient = useQueryClient();
  const solve = useServerFn(solveDoubt);

  const [subject, setSubject] = useState<string>("Mathematics");
  const [questionText, setQuestionText] = useState("");
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [openDoubt, setOpenDoubt] = useState<string | null>(null);

  const { data: doubts } = useQuery({
    queryKey: ["doubts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("doubts")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return data;
    },
  });

  const mutation = useMutation({
    mutationFn: () =>
      solve({
        data: {
          subject,
          questionText: questionText || undefined,
          imageDataUrl: imageDataUrl ?? undefined,
        },
      }),
    onSuccess: (doubt) => {
      toast.success("Solved! +10 XP ⚡");
      setQuestionText("");
      setImageDataUrl(null);
      setOpenDoubt(doubt.id);
      queryClient.invalidateQueries({ queryKey: ["doubts"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to solve"),
  });

  async function handleImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      toast.error("Image must be under 4MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setImageDataUrl(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function deleteDoubt(id: string) {
    await supabase.from("doubts").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["doubts"] });
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">DoubtSnap AI</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Snap a photo of any question or type it — get a step-by-step solution.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-3 p-5">
          <SelectNative value={subject} onChange={(e) => setSubject(e.target.value)} className="sm:w-56">
            {DOUBT_SUBJECTS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </SelectNative>
          <Textarea
            placeholder="Type your question here... or just attach a photo below"
            rows={3}
            value={questionText}
            onChange={(e) => setQuestionText(e.target.value)}
          />
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
              <Camera className="h-4 w-4" />
              {imageDataUrl ? "Photo attached ✓" : "Snap / upload photo"}
              <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleImage} />
            </label>
            {imageDataUrl && (
              <button className="text-xs text-destructive underline" onClick={() => setImageDataUrl(null)}>
                Remove
              </button>
            )}
            <div className="flex-1" />
            <Button
              variant="hero"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending || (!questionText.trim() && !imageDataUrl)}
            >
              {mutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {mutation.isPending ? "Solving..." : "Solve It"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold">Solved doubts ({doubts?.length ?? 0})</h2>
        {doubts?.map((doubt) => (
          <Card key={doubt.id}>
            <CardHeader className="cursor-pointer" onClick={() => setOpenDoubt(openDoubt === doubt.id ? null : doubt.id)}>
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="text-sm font-semibold">
                  <span className="mr-2 rounded-full bg-accent/15 px-2 py-0.5 text-xs text-accent">{doubt.subject}</span>
                  {(doubt.question_text ?? "").slice(0, 80) || "Photo question"}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{format(new Date(doubt.created_at), "d MMM")}</span>
                  <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${openDoubt === doubt.id ? "rotate-180" : ""}`} />
                </div>
              </div>
            </CardHeader>
            {openDoubt === doubt.id && (
              <CardContent>
                <div className="prose-notes text-sm">
                  <ReactMarkdown>{doubt.solution ?? ""}</ReactMarkdown>
                </div>
                <div className="mt-4 flex justify-end">
                  <Button variant="ghost" size="sm" onClick={() => deleteDoubt(doubt.id)}>
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
