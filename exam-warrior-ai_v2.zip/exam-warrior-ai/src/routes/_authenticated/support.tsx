import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SelectNative } from "@/components/ui/select-native";

export const Route = createFileRoute("/_authenticated/support")({
  component: SupportPage,
});

function SupportPage() {
  const qc = useQueryClient();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [category, setCategory] = useState("feedback");

  const { data: tickets } = useQuery({
    queryKey: ["my-tickets"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];
      const { data } = await supabase
        .from("support_tickets")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const submit = useMutation({
    mutationFn: async () => {
      if (!subject.trim() || !message.trim()) throw new Error("Subject and message required");
      if (subject.length > 200) throw new Error("Subject too long");
      if (message.length > 2000) throw new Error("Message too long");
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not signed in");
      const { error } = await supabase.from("support_tickets").insert({
        user_id: user.id,
        subject: subject.trim(),
        message: message.trim(),
        category,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Sent! We'll get back to you soon.");
      setSubject(""); setMessage("");
      qc.invalidateQueries({ queryKey: ["my-tickets"] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold">Support & Feedback</h1>
        <p className="text-sm text-muted-foreground">Report a bug, request a feature, or send us a note.</p>
      </div>

      <Card>
        <CardContent className="p-5 space-y-4">
          <SelectNative value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="feedback">General feedback</option>
            <option value="bug">Bug report</option>
            <option value="feature">Feature request</option>
            <option value="account">Account issue</option>
            <option value="other">Other</option>
          </SelectNative>
          <Input placeholder="Subject" maxLength={200} value={subject} onChange={(e) => setSubject(e.target.value)} />
          <Textarea rows={6} placeholder="Describe your feedback in detail..." maxLength={2000} value={message} onChange={(e) => setMessage(e.target.value)} />
          <div className="flex justify-end">
            <Button onClick={() => submit.mutate()} disabled={submit.isPending}>{submit.isPending ? "Sending..." : "Send message"}</Button>
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="font-display text-xl font-bold mb-3">Your tickets</h2>
        <div className="space-y-3">
          {(tickets ?? []).map((t: any) => (
            <Card key={t.id}>
              <CardContent className="p-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-semibold">{t.subject}</div>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${t.status === "closed" ? "bg-secondary" : t.status === "in_progress" ? "bg-primary/15 text-primary" : "bg-gold/20 text-gold"}`}>{t.status}</span>
                </div>
                <p className="text-sm text-muted-foreground whitespace-pre-line">{t.message}</p>
                {t.admin_reply && (
                  <div className="mt-2 rounded-md bg-primary/10 border border-primary/20 p-3 text-sm">
                    <div className="text-xs font-semibold text-primary mb-1">Reply from team</div>
                    <div className="whitespace-pre-line">{t.admin_reply}</div>
                  </div>
                )}
                <div className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleString()}</div>
              </CardContent>
            </Card>
          ))}
          {tickets?.length === 0 && <p className="text-sm text-muted-foreground">No tickets yet.</p>}
        </div>
      </div>
    </div>
  );
}
