import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppLayout } from "@/components/app/AppLayout";

const GUEST_LIMIT_MS = 60 * 60 * 1000;

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    if (data.user.is_anonymous) {
      const age = Date.now() - new Date(data.user.created_at).getTime();
      if (age > GUEST_LIMIT_MS) {
        await supabase.auth.signOut();
        throw redirect({ to: "/auth" });
      }
    }
    return { user: data.user };
  },
  component: () => (
    <AppLayout>
      <Outlet />
    </AppLayout>
  ),
});
