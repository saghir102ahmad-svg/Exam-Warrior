import { createFileRoute, Link } from "@tanstack/react-router";
import { Swords, Mail, Youtube, Instagram, Facebook, Twitter, Star, Share2, RefreshCw, MessageSquare, FileText, Shield, HelpCircle, History } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { APP_META, FEATURES_LIST } from "@/lib/app-meta";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: `About — ${APP_META.name}` },
      { name: "description", content: APP_META.description },
      { property: "og:title", content: `About ${APP_META.name}` },
      { property: "og:description", content: APP_META.description },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  async function share() {
    const shareData = { title: APP_META.name, text: APP_META.tagline, url: APP_META.website };
    try {
      if (navigator.share) await navigator.share(shareData);
      else {
        await navigator.clipboard.writeText(APP_META.website);
        toast.success("Link copied to clipboard");
      }
    } catch {/* cancelled */}
  }

  function rate() {
    toast.success("Thanks! Ratings will open in the app store once we launch there.");
  }

  function checkUpdates() {
    toast.success(`You're on the latest version (v${APP_META.version}).`);
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg gradient-primary shadow-glow">
              <Swords className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-lg font-bold">
              Exam<span className="text-gradient">Warrior</span> AI
            </span>
          </Link>
          <Button variant="ghost" asChild><Link to="/">Home</Link></Button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-12 space-y-8">
        <section className="text-center space-y-4">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl gradient-primary shadow-glow">
            <Swords className="h-10 w-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-4xl font-bold">{APP_META.name}</h1>
          <p className="text-muted-foreground">{APP_META.tagline}</p>
          <span className="inline-block rounded-full bg-secondary px-3 py-1 text-xs font-semibold">Version {APP_META.version}</span>
        </section>

        <Card>
          <CardContent className="p-6 space-y-2">
            <h2 className="font-display text-xl font-bold">About</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{APP_META.description}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-2">
            <h2 className="font-display text-xl font-bold">Mission & Purpose</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{APP_META.mission}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-3">
            <h2 className="font-display text-xl font-bold">Features</h2>
            <ul className="grid gap-2 sm:grid-cols-2">
              {FEATURES_LIST.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-3">
          <Button variant="secondary" onClick={rate}><Star className="mr-2 h-4 w-4" />Rate app</Button>
          <Button variant="secondary" onClick={share}><Share2 className="mr-2 h-4 w-4" />Share app</Button>
          <Button variant="secondary" onClick={checkUpdates}><RefreshCw className="mr-2 h-4 w-4" />Check updates</Button>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <h2 className="font-display text-xl font-bold">Developer & Contact</h2>
            <div className="grid gap-2 text-sm">
              <div><span className="text-muted-foreground">Developer:</span> {APP_META.developer}</div>
              <a className="flex items-center gap-2 text-primary hover:underline" href={`mailto:${APP_META.contactEmail}`}>
                <Mail className="h-4 w-4" />{APP_META.contactEmail}
              </a>
              <a className="flex items-center gap-2 text-primary hover:underline" href={APP_META.website} target="_blank" rel="noreferrer">
                🌐 {APP_META.website}
              </a>
            </div>
            <div className="flex flex-wrap gap-3 pt-2">
              <a href={APP_META.socials.youtube} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm hover:bg-secondary"><Youtube className="h-4 w-4" />YouTube</a>
              <a href={APP_META.socials.instagram} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm hover:bg-secondary"><Instagram className="h-4 w-4" />Instagram</a>
              <a href={APP_META.socials.facebook} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm hover:bg-secondary"><Facebook className="h-4 w-4" />Facebook</a>
              <a href={APP_META.socials.twitter} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm hover:bg-secondary"><Twitter className="h-4 w-4" />X / Twitter</a>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-3 sm:grid-cols-2">
          <Link to="/privacy" className="flex items-center gap-3 rounded-lg border border-border p-4 hover:bg-secondary transition-colors">
            <Shield className="h-5 w-5 text-primary" /><span className="font-medium">Privacy Policy</span>
          </Link>
          <Link to="/terms" className="flex items-center gap-3 rounded-lg border border-border p-4 hover:bg-secondary transition-colors">
            <FileText className="h-5 w-5 text-primary" /><span className="font-medium">Terms & Conditions</span>
          </Link>
          <Link to="/faq" className="flex items-center gap-3 rounded-lg border border-border p-4 hover:bg-secondary transition-colors">
            <HelpCircle className="h-5 w-5 text-primary" /><span className="font-medium">FAQ</span>
          </Link>
          <Link to="/changelog" className="flex items-center gap-3 rounded-lg border border-border p-4 hover:bg-secondary transition-colors">
            <History className="h-5 w-5 text-primary" /><span className="font-medium">Changelog</span>
          </Link>
          <Link to="/support" className="flex items-center gap-3 rounded-lg border border-border p-4 hover:bg-secondary transition-colors sm:col-span-2">
            <MessageSquare className="h-5 w-5 text-primary" /><span className="font-medium">Support & Feedback</span>
          </Link>
        </div>

        <p className="pt-4 text-center text-xs text-muted-foreground">{APP_META.copyright}</p>
      </main>
    </div>
  );
}
