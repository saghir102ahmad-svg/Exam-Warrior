import { createFileRoute, Link } from "@tanstack/react-router";
import { APP_META } from "@/lib/app-meta";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: `Privacy Policy — ${APP_META.name}` },
      { name: "description", content: `How ${APP_META.name} collects, uses, and protects your data.` },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-3xl px-4 py-12">
        <Link to="/about" className="text-sm text-primary hover:underline">← Back to About</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">Privacy Policy</h1>
        <p className="mt-1 text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>

        <div className="prose prose-invert mt-8 max-w-none space-y-6 text-sm leading-relaxed text-muted-foreground">
          <p>This Privacy Policy describes how {APP_META.name} ("we", "our", or "us") collects, uses, and protects your information when you use our AI-powered study application.</p>

          <section>
            <h2 className="text-lg font-semibold text-foreground">1. Information We Collect</h2>
            <p>We collect: your name/display name, email address, education level (school/college/university), language preference, and study activity (notes generated, quizzes taken, flashcards reviewed, doubts submitted, XP, streaks, and study plans). If you sign in with Google, we receive your Google-provided profile information.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">2. How We Use Your Data</h2>
            <p>Your data is used to: (a) provide the app's features and personalize your study experience, (b) generate AI notes, quizzes, and answers, (c) show your progress and leaderboard position, (d) improve the app, and (e) send optional broadcast notifications from administrators.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">3. AI Processing</h2>
            <p>Text and images you submit to AI features (Notes, MCQ, Flashcards, DoubtSnap, Assistant) are sent to our AI providers to generate responses. We do not sell your data. AI providers process the content solely to return a response and do not use your data to train their models under our agreements.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">4. Data Storage & Security</h2>
            <p>We store your data using industry-standard cloud infrastructure with Row Level Security so only you (and, where necessary, administrators) can access your personal records. Passwords are hashed. All connections are encrypted in transit.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">5. Sharing</h2>
            <p>We do not sell your personal information. Aggregate, non-identifying analytics may be shared publicly. Your display name, XP, level and streak appear on public leaderboards; you may change your display name at any time.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">6. Children</h2>
            <p>The service is intended for students. If you are under the age of digital consent in your country, please use the app with a parent or guardian's permission.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">7. Your Rights</h2>
            <p>You can access, correct, or delete your data at any time from your profile page, or by contacting us at <a className="text-primary" href={`mailto:${APP_META.contactEmail}`}>{APP_META.contactEmail}</a>. Deleting your account removes your personal records; anonymized aggregate metrics may be retained.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">8. Changes</h2>
            <p>We may update this policy. Material changes will be announced in the app. Continued use after changes means you accept the updated policy.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">9. Contact</h2>
            <p>Questions? Email <a className="text-primary" href={`mailto:${APP_META.contactEmail}`}>{APP_META.contactEmail}</a>.</p>
          </section>

          <p className="pt-8 text-xs">This document is provided for informational purposes and does not constitute legal advice.</p>
        </div>
      </main>
    </div>
  );
}
