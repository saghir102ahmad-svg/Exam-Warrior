import { createFileRoute, Link } from "@tanstack/react-router";
import { APP_META } from "@/lib/app-meta";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: `Terms & Conditions — ${APP_META.name}` },
      { name: "description", content: `Rules for using ${APP_META.name}.` },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-3xl px-4 py-12">
        <Link to="/about" className="text-sm text-primary hover:underline">← Back to About</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">Terms & Conditions</h1>
        <p className="mt-1 text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>

        <div className="prose prose-invert mt-8 max-w-none space-y-6 text-sm leading-relaxed text-muted-foreground">
          <section>
            <h2 className="text-lg font-semibold text-foreground">1. Acceptance</h2>
            <p>By creating an account or using {APP_META.name} ("the Service"), you agree to these Terms. If you do not agree, do not use the Service.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">2. Eligibility & Account</h2>
            <p>You must provide accurate registration information and keep your credentials secure. You are responsible for all activity on your account. One person per account.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">3. Acceptable Use</h2>
            <p>You agree not to: (a) submit unlawful, hateful, harassing, or infringing content, (b) attempt to reverse engineer or disrupt the Service, (c) use the Service to cheat on live exams or violate your institution's academic integrity policies, (d) automate access without written permission, or (e) impersonate another person. We may suspend or terminate accounts that violate these rules.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">4. AI-Generated Content</h2>
            <p>AI outputs (notes, MCQs, flashcards, solutions, chat replies) can be incorrect or incomplete. You are responsible for verifying accuracy before relying on them for exams or assignments. Do not treat AI answers as professional advice.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">5. Your Content</h2>
            <p>You retain ownership of content you submit. You grant us a limited license to store, display, and process your content for the purpose of providing the Service to you.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">6. Fees & Premium</h2>
            <p>Core features are free. Premium features and pricing (if introduced) will be disclosed clearly before purchase.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">7. Termination</h2>
            <p>You may delete your account at any time from your profile page. We may suspend or terminate accounts that violate these Terms or applicable law.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">8. Disclaimer</h2>
            <p>The Service is provided "as is" without warranties of any kind. To the maximum extent permitted by law, {APP_META.name} is not liable for indirect, incidental, or consequential damages arising from use of the Service, including exam outcomes.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">9. Changes</h2>
            <p>We may update these Terms. Continued use after changes constitutes acceptance.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-foreground">10. Contact</h2>
            <p>Questions? Email <a className="text-primary" href={`mailto:${APP_META.contactEmail}`}>{APP_META.contactEmail}</a>.</p>
          </section>

          <p className="pt-8 text-xs">This document is provided for informational purposes and does not constitute legal advice.</p>
        </div>
      </main>
    </div>
  );
}
