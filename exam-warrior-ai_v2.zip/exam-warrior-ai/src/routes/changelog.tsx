import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { APP_META } from "@/lib/app-meta";

export const Route = createFileRoute("/changelog")({
  head: () => ({
    meta: [
      { title: `Changelog — ${APP_META.name}` },
      { name: "description", content: `What's new in ${APP_META.name}.` },
    ],
  }),
  component: ChangelogPage,
});

function ChangelogPage() {
  const { data } = useQuery({
    queryKey: ["changelog-public"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_changelog")
        .select("*")
        .eq("is_published", true)
        .order("released_at", { ascending: false });
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-3xl px-4 py-12">
        <Link to="/about" className="text-sm text-primary hover:underline">← Back to About</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">Changelog</h1>
        <p className="mt-1 text-sm text-muted-foreground">What's new in {APP_META.name}.</p>

        <div className="mt-8 space-y-6">
          {(data ?? []).map((entry: any) => (
            <div key={entry.id} className="rounded-lg border border-border p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <div>
                  <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary">v{entry.version}</span>
                  <h2 className="mt-2 font-display text-lg font-bold">{entry.title}</h2>
                </div>
                <span className="text-xs text-muted-foreground">{new Date(entry.released_at).toLocaleDateString()}</span>
              </div>
              <p className="mt-2 whitespace-pre-line text-sm text-muted-foreground">{entry.notes}</p>
            </div>
          ))}
          {data?.length === 0 && <p className="text-sm text-muted-foreground">No entries yet.</p>}
        </div>
      </main>
    </div>
  );
}
