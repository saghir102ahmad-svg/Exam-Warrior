import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  FileText,
  Target,
  Layers,
  CalendarCheck,
  Camera,
  MessageCircle,
  Trophy,
  Flame,
  BarChart3,
  Sparkles,
  Check,
  Swords,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import heroImage from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  component: LandingPage,
});

const FEATURES = [
  { icon: FileText, title: "AI Notes Generator", desc: "Turn any chapter, PDF text or photo into short, exam-ready notes — in English or Urdu." },
  { icon: Target, title: "AI MCQ Generator", desc: "Unlimited MCQs at Easy, Medium or Hard difficulty with instant checking and explanations." },
  { icon: Layers, title: "Smart Flashcards", desc: "Auto-generated flashcards with spaced repetition so you remember what matters." },
  { icon: CalendarCheck, title: "Revision Planner", desc: "Enter your exam date — AI builds a personalized daily study timetable with goals." },
  { icon: Camera, title: "DoubtSnap AI", desc: "Snap a photo of any question and get a step-by-step solution in seconds." },
  { icon: MessageCircle, title: "24/7 Study Assistant", desc: "An AI tutor that explains concepts simply and generates practice questions." },
  { icon: BarChart3, title: "Weak Topic Analyzer", desc: "See exactly which chapters are costing you marks and what to revise next." },
  { icon: Flame, title: "StudyQuest XP & Streaks", desc: "Earn XP, level up, keep daily streaks and unlock achievement badges." },
  { icon: Trophy, title: "Leaderboards", desc: "Compete with students everywhere and climb the global XP leaderboard." },
];

const FREE_FEATURES = ["AI notes & summaries", "MCQ quizzes with explanations", "Flashcards & spaced repetition", "Study planner & XP system"];
const PRO_FEATURES = ["Everything in Free", "Unlimited AI generations", "Priority AI responses", "Advanced analytics", "Exam Rescue Mode (soon)"];

function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg gradient-primary shadow-glow">
              <Swords className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-lg font-bold">
              Exam<span className="text-gradient">Warrior</span> AI
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
            <Button variant="hero" asChild>
              <Link to="/auth">Get Started Free</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="gradient-hero relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 lg:grid-cols-2 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1 text-xs font-semibold text-accent">
              <Sparkles className="h-3.5 w-3.5" />
              Your AI-powered study companion
            </div>
            <h1 className="font-display text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
              Study smarter.
              <br />
              <span className="text-gradient">Win every exam.</span>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-muted-foreground">
              AI notes, unlimited MCQs, smart flashcards, doubt solving and a personalized revision
              plan — everything a school, college or university student needs, in one app.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button variant="hero" size="lg" asChild>
                <Link to="/auth">Start Studying Free</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="#features">Explore Features</a>
              </Button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              Free forever plan · English & Urdu support · No credit card needed
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <img
              src={heroImage}
              alt="Student studying at night with AI-powered flashcards and quizzes floating around"
              width={1536}
              height={1024}
              className="rounded-2xl border border-border shadow-card"
            />
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-4 py-16 lg:py-24">
        <div className="mb-12 text-center">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">
            One app. <span className="text-gradient">Every study superpower.</span>
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Built for students who want results — powered by AI at every step.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
            >
              <Card className="h-full transition-all hover:border-primary/40 hover:shadow-glow">
                <CardContent className="p-5">
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15">
                    <f.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-display text-base font-bold">{f.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="border-t border-border bg-sidebar/50">
        <div className="mx-auto max-w-4xl px-4 py-16 lg:py-24">
          <div className="mb-12 text-center">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Simple pricing</h2>
            <p className="mt-3 text-muted-foreground">Start free. Upgrade when you're ready.</p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-display text-xl font-bold">Free</h3>
                <p className="mt-1 text-3xl font-bold">
                  $0<span className="text-sm font-normal text-muted-foreground">/forever</span>
                </p>
                <ul className="mt-5 space-y-2.5">
                  {FREE_FEATURES.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-success" /> {f}
                    </li>
                  ))}
                </ul>
                <Button variant="outline" className="mt-6 w-full" asChild>
                  <Link to="/auth">Get Started</Link>
                </Button>
              </CardContent>
            </Card>
            <Card className="border-primary/50 shadow-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-xl font-bold">Premium</h3>
                  <span className="rounded-full bg-primary/15 px-2.5 py-0.5 text-xs font-semibold text-primary">
                    Coming soon
                  </span>
                </div>
                <p className="mt-1 text-3xl font-bold">
                  $4.99<span className="text-sm font-normal text-muted-foreground">/month</span>
                </p>
                <p className="text-xs text-muted-foreground">or $39.99/year (save 33%)</p>
                <ul className="mt-5 space-y-2.5">
                  {PRO_FEATURES.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-success" /> {f}
                    </li>
                  ))}
                </ul>
                <Button variant="hero" className="mt-6 w-full" asChild>
                  <Link to="/auth">Start Free Today</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA + footer */}
      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-12 text-center">
          <h2 className="font-display text-2xl font-bold">
            Ready to become an <span className="text-gradient">Exam Warrior</span>?
          </h2>
          <Button variant="hero" size="lg" className="mt-6" asChild>
            <Link to="/auth">Create Free Account</Link>
          </Button>
          <p className="mt-8 text-xs text-muted-foreground">
            © {new Date().getFullYear()} Exam Warrior AI — Study smarter, win every exam.
          </p>
        </div>
      </footer>
    </div>
  );
}
