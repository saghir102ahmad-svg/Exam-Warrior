import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { APP_META } from "@/lib/app-meta";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: `FAQ — ${APP_META.name}` },
      { name: "description", content: `Frequently asked questions about ${APP_META.name}.` },
    ],
  }),
  component: FaqPage,
});

const FAQS = [
  { q: "Is Exam Warrior AI free?", a: "Yes — the core features (AI Notes, MCQs, Flashcards, DoubtSnap, Study Assistant, Planner, XP & Leaderboards) are free to use. Premium tiers may be added later." },
  { q: "Which subjects and levels are supported?", a: "The app supports school, college, and university students across Math, Physics, Chemistry, Biology, Computer Science, English, and general subjects. You can add any custom subject." },
  { q: "How accurate is the AI?", a: "Our AI is powered by state-of-the-art models but can still make mistakes. Always double-check important answers against your textbook or teacher — treat AI as a smart tutor, not an oracle." },
  { q: "Does it support Urdu?", a: "Yes. Notes and explanations can be generated in English or Urdu — set your preferred language in your profile." },
  { q: "How do XP, levels, and streaks work?", a: "You earn XP for every study action: generating notes (+20), completing quizzes (+30), reviewing flashcards (+2), solving doubts (+10), and finishing planned tasks (+5). Reaching XP thresholds levels you up. Study every day to keep your streak alive." },
  { q: "Can I use it offline?", a: "The app currently requires an internet connection for AI features. Offline access is on the roadmap." },
  { q: "How do I delete my account?", a: "Open Profile → Account → Delete Account. This removes your personal data. You can also email us to request deletion." },
  { q: "Is my data private?", a: "Yes. Your notes, quizzes, and doubts are protected with Row Level Security so only you can see them. Read the Privacy Policy for full details." },
  { q: "I found a bug or want to suggest a feature — where do I send it?", a: "Use the Support & Feedback page inside the app, or email us at " + APP_META.contactEmail + "." },
];

function FaqPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-3xl px-4 py-12">
        <Link to="/about" className="text-sm text-primary hover:underline">← Back to About</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">Frequently Asked Questions</h1>

        <div className="mt-8 space-y-3">
          {FAQS.map((f, i) => (
            <div key={i} className="rounded-lg border border-border">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between gap-3 p-4 text-left font-medium"
              >
                <span>{f.q}</span>
                <ChevronDown className={`h-4 w-4 shrink-0 transition-transform ${open === i ? "rotate-180" : ""}`} />
              </button>
              {open === i && <div className="border-t border-border px-4 py-3 text-sm text-muted-foreground">{f.a}</div>}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
