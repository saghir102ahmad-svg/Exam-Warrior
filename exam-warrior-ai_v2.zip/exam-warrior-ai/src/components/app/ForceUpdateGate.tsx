import { AlertTriangle, Download } from "lucide-react";
import { useAppConfig, compareVersion } from "@/hooks/useAppConfig";
import { APP_META } from "@/lib/app-meta";
import { Button } from "@/components/ui/button";
import type { ReactNode } from "react";

export function ForceUpdateGate({ children }: { children: ReactNode }) {
  const { data: cfg } = useAppConfig();

  const behind = cfg ? compareVersion(APP_META.version, cfg.min_required_version) < 0 : false;
  const mustUpdate = !!cfg?.force_update && behind;

  if (!mustUpdate) return <>{children}</>;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-md p-6">
      <div className="max-w-md text-center space-y-5 rounded-2xl border border-border bg-card p-8 shadow-glow">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/15">
          <AlertTriangle className="h-7 w-7 text-destructive" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold">Update required</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {cfg?.update_message || "A new version of Exam Warrior AI is required to continue."}
          </p>
          <p className="mt-3 text-xs text-muted-foreground">
            Your version: <span className="font-mono">{APP_META.version}</span> · Required:{" "}
            <span className="font-mono">{cfg?.min_required_version}</span>
          </p>
        </div>
        {cfg?.update_url ? (
          <Button variant="hero" className="w-full" onClick={() => window.location.assign(cfg.update_url!)}>
            <Download className="h-4 w-4" /> Update now
          </Button>
        ) : (
          <Button variant="hero" className="w-full" onClick={() => window.location.reload()}>
            Reload
          </Button>
        )}
      </div>
    </div>
  );
}
