import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  FileText,
  Target,
  Layers,
  CalendarCheck,
  Camera,
  MessageCircle,
  Trophy,
  BookOpen,
  User,
  Swords,
  Flame,
  Zap,
  LogOut,
  Bell,
  ShieldCheck,
  Info,
} from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/hooks/useProfile";
import { useRoles } from "@/hooks/useRoles";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/notes", label: "AI Notes", icon: FileText },
  { to: "/quiz", label: "MCQ Quiz", icon: Target },
  { to: "/flashcards", label: "Flashcards", icon: Layers },
  { to: "/planner", label: "Planner", icon: CalendarCheck },
  { to: "/doubts", label: "DoubtSnap", icon: Camera },
  { to: "/assistant", label: "Assistant", icon: MessageCircle },
  { to: "/books", label: "Books", icon: BookOpen },
  { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/subjects", label: "Subjects", icon: BookOpen },
  { to: "/profile", label: "Profile", icon: User },
] as const;

const MOBILE_NAV = [
  { to: "/dashboard", label: "Home", icon: LayoutDashboard },
  { to: "/notes", label: "Notes", icon: FileText },
  { to: "/quiz", label: "Quiz", icon: Target },
  { to: "/flashcards", label: "Cards", icon: Layers },
  { to: "/assistant", label: "Ask AI", icon: MessageCircle },
] as const;

export function AppLayout({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { data: profile } = useProfile();
  const { data: roles } = useRoles();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-border bg-sidebar lg:flex">
        <Link to="/dashboard" className="flex items-center gap-2.5 px-5 py-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg gradient-primary shadow-glow">
            <Swords className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-display text-lg font-bold">
            Exam<span className="text-gradient">Warrior</span>
          </span>
        </Link>
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
          {NAV_ITEMS.map((item) => {
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary/15 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                )}
              >
                <item.icon className="h-4.5 w-4.5" />
                {item.label}
              </Link>
            );
          })}
          <Link to="/notifications" className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors", pathname.startsWith("/notifications") ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground")}><Bell className="h-4.5 w-4.5" />Notifications</Link>
          <Link to="/about" className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors", pathname.startsWith("/about") ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground")}><Info className="h-4.5 w-4.5" />About</Link>
          {roles?.isModerator && (
            <Link to="/admin" className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors", pathname.startsWith("/admin") ? "bg-primary/15 text-primary" : "text-gold hover:bg-secondary")}><ShieldCheck className="h-4.5 w-4.5" />Admin</Link>
          )}
        </nav>
        <button
          onClick={handleSignOut}
          className="mx-3 mb-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <LogOut className="h-4.5 w-4.5" />
          Sign out
        </button>
      </aside>

      <div className="flex min-h-screen w-full flex-col lg:pl-60">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-background/80 px-4 backdrop-blur-md lg:px-8">
          <Link to="/dashboard" className="flex items-center gap-2 lg:hidden">
            <div className="flex h-7 w-7 items-center justify-center rounded-md gradient-primary">
              <Swords className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-display text-base font-bold">
              Exam<span className="text-gradient">Warrior</span>
            </span>
          </Link>
          <div className="hidden lg:block" />
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold">
              <Flame className="h-3.5 w-3.5 text-primary" />
              {profile?.streak_count ?? 0} day{(profile?.streak_count ?? 0) === 1 ? "" : "s"}
            </div>
            <div className="flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold">
              <Zap className="h-3.5 w-3.5 text-gold" />
              {profile?.xp ?? 0} XP
            </div>
            <Link
              to="/profile"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-bold uppercase text-primary lg:hidden"
            >
              {(profile?.display_name ?? "S").slice(0, 1)}
            </Link>
          </div>
        </header>

        <main className="flex-1 px-4 pb-24 pt-6 lg:px-8 lg:pb-10">{children}</main>

        {/* Mobile bottom nav */}
        <nav className="fixed inset-x-0 bottom-0 z-40 flex items-stretch justify-around border-t border-border bg-sidebar/95 backdrop-blur-md lg:hidden">
          {MOBILE_NAV.map((item) => {
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium transition-colors",
                  active ? "text-primary" : "text-muted-foreground",
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
